class AuraCanvasEditor {
  constructor() {
    this.connector = new GoogleSheetsConnector();
    this.gridGenerator = new GridGenerator();
    this.sections = [];
    this.sheetData = [];
    this.selectedSection = null;
    this.selectedCard = null; // Track selected card for style preview
    this.styleSets = [];
    this.currentStyle = null;
    this.gridConfig = {
      columns: 3,
      columnsDesktop: 4,
      columnsTablet: 2,
      columnsPhone: 1,
      gap: 24,
      minWidth: 300,
      maxWidth: 1440,
      sectionPadding: 40,
      cardLimit: 0,
      showPlaceholders: true
    };
    this.previewWidth = 'desktop';
    this.previewTheme = 'light';
    this.previewDirection = 'ltr';
    this.originalHead = '';
    this.originalHtmlClass = '';

    this.init();
  }

  async init() {
    try {
      await this.connector.init();
      this.bindEvents();
      this.initSidebarResizer();
      this.setupCardClickListener(); // Listen for card clicks from iframe
      this.loadSavedData();
      await this.loadLocalStyles();
      this.renderStyleSelect();
      this.showToast('Welcome to Aura Canvas Editor', 'success');
    } catch (error) {
      console.error('Failed to initialize editor:', error);
      this.showToast('Initialization failed: ' + error.message, 'error');
    }
  }

  initSidebarResizer() {
    const resizer = document.getElementById('sidebarResizer');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    let isResizing = false;

    resizer.addEventListener('mousedown', (e) => {
      isResizing = true;
      resizer.classList.add('resizing');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      
      const startX = e.clientX;
      const startWidth = sidebar.offsetWidth;
      
      const onMouseMove = (moveEvent) => {
        if (!isResizing) return;
        
        const deltaX = moveEvent.clientX - startX;
        const newWidth = startWidth + deltaX;
        
        if (newWidth >= 280 && newWidth <= 600) {
          sidebar.style.width = newWidth + 'px';
        }
      };
      
      const onMouseUp = () => {
        isResizing = false;
        resizer.classList.remove('resizing');
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
      };
      
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });
  }

  setupCardClickListener() {
    // Listen for messages from preview iframe when cards are clicked
    window.addEventListener('message', (event) => {
      if (event.data.type === 'cardClick') {
        console.log('Card clicked:', event.data);
        this.selectedCard = {
          index: event.data.index,
          data: event.data.data
        };
        this.showCardStylePreview();
        this.switchTab('styles'); // Auto switch to Style Sets tab
      }
    });
  }

  showCardStylePreview() {
    if (!this.currentStyle || !this.selectedCard) {
      document.getElementById('stylePreviewCard').style.display = 'none';
      return;
    }
    
    const card = this.selectedCard;
    const style = this.currentStyle;
    
    // Show preview card
    document.getElementById('stylePreviewCard').style.display = 'block';
    
    // Update preview info
    const nameEl = document.getElementById('stylePreviewName');
    if (nameEl) {
      const cardName = card.data.name || card.data.title || `Card ${card.index + 1}`;
      nameEl.textContent = `${style.name} - Selected: ${cardName}`;
    }
    
    // Render actual card preview
    const imageEl = document.getElementById('stylePreviewImage');
    if (imageEl) {
      const cardHtml = this.renderCard(card.data);
      imageEl.innerHTML = `<div class="card" style="
        width: 100%;
        height: 100%;
        transform: scale(0.95);
        background: ${style.cardBg || '#fff'};
        border-radius: ${style.cardRadius || 8}px;
        padding: ${style.cardPadding || 16}px;
        overflow: auto;
      ">${cardHtml}</div>`;
    }
    
    // Update columns info
    const colsEl = document.getElementById('stylePreviewCols');
    if (colsEl) {
      const cols = style.grid?.columns || this.gridConfig.columnsDesktop || 4;
      colsEl.textContent = `${cols} columns (Desktop)`;
    }
    
    // Update fields info
    const fieldsEl = document.getElementById('stylePreviewFields');
    if (fieldsEl) {
      const fields = Object.keys(card.data);
      fieldsEl.textContent = fields.join(', ');
    }
  }

  bindEvents() {
    // Remove any existing listeners first to prevent duplicates
    const removeAllListeners = (selector) => {
      const el = document.getElementById(selector);
      if (el) {
        const newEl = el.cloneNode(true);
        el.parentNode.replaceChild(newEl, el);
        return newEl;
      }
      return null;
    };

    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.tab));
    });

    const newProjectBtn = removeAllListeners('newProjectBtn');
    const clearStorageBtn = removeAllListeners('clearStorageBtn');
    const importHtmlBtn = removeAllListeners('importHtmlBtn');
    const exportBtn = removeAllListeners('exportBtn');
    const exportProjectBtn = removeAllListeners('exportProjectBtn');
    const addSectionBtn = removeAllListeners('addSectionBtn');
    const loadDataBtn = removeAllListeners('loadDataBtn');
    const clearCacheBtn = removeAllListeners('clearCacheBtn');
    const loadStyleBtn = removeAllListeners('loadStyleBtn');
    const addTallyBtn = removeAllListeners('addTallyBtn');
    const applyTallySettingsBtn = removeAllListeners('applyTallySettingsBtn');
    const refreshPreviewBtn = removeAllListeners('refreshPreviewBtn');
    const fileInput = removeAllListeners('fileInput');
    const previewDesktopBtn = removeAllListeners('previewDesktopBtn');
    const previewTabletBtn = removeAllListeners('previewTabletBtn');
    const previewMobileBtn = removeAllListeners('previewMobileBtn');

    if (newProjectBtn) newProjectBtn.addEventListener('click', () => this.newProject());
    if (clearStorageBtn) clearStorageBtn.addEventListener('click', () => this.clearStorage());
    if (importHtmlBtn) importHtmlBtn.addEventListener('click', () => this.importHtml());
    if (exportBtn) exportBtn.addEventListener('click', () => this.exportHtml());
    if (exportProjectBtn) exportProjectBtn.addEventListener('click', () => this.exportProject());
    if (addSectionBtn) addSectionBtn.addEventListener('click', () => this.addSection());
    if (loadDataBtn) loadDataBtn.addEventListener('click', () => this.loadSheetData());
    if (clearCacheBtn) clearCacheBtn.addEventListener('click', () => this.clearCache());
    if (loadStyleBtn) loadStyleBtn.addEventListener('click', () => this.loadLocalStyle());
    if (addTallyBtn) addTallyBtn.addEventListener('click', () => this.addTallySection());
    if (applyTallySettingsBtn) applyTallySettingsBtn.addEventListener('click', () => this.applyTallySettings());
    if (refreshPreviewBtn) refreshPreviewBtn.addEventListener('click', () => this.refreshPreview());
    if (fileInput) fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
    if (previewDesktopBtn) previewDesktopBtn.addEventListener('click', () => this.setPreviewWidth('desktop'));
    if (previewTabletBtn) previewTabletBtn.addEventListener('click', () => this.setPreviewWidth('tablet'));
    if (previewMobileBtn) previewMobileBtn.addEventListener('click', () => this.setPreviewWidth('mobile'));

    this.bindGridControls();
    this.bindStylePanelControls();
  }

  bindGridControls() {
    const controls = [
      'gridColumnsDesktop', 'gridColumnsTablet', 'gridColumnsPhone',
      'gridGapNum', 'gridMinWidthNum', 'gridMaxWidthNum', 'gridCardLimitNum',
      'gridSectionPadding', 'showPlaceholders'
    ];
    controls.forEach(id => {
      const input = document.getElementById(id);
      if (input) {
        input.addEventListener('input', () => {
          this.updateGridConfigFromControls();
          this.updateGridPreviewInfo();
        });
        input.addEventListener('change', () => {
          this.updateGridConfigFromControls();
          this.updateGridPreviewInfo();
        });
      }
    });

    const applyGridBtn = document.getElementById('applyGridBtn');
    if (applyGridBtn) {
      // Clone to remove old listeners
      const newApplyGridBtn = applyGridBtn.cloneNode(true);
      applyGridBtn.parentNode.replaceChild(newApplyGridBtn, applyGridBtn);
      newApplyGridBtn.addEventListener('click', () => this.applyGridConfig());
    }

    const applyModifyBtn = document.getElementById('applyModifyBtn');
    if (applyModifyBtn) {
      // Clone to remove old listeners
      const newApplyModifyBtn = applyModifyBtn.cloneNode(true);
      applyModifyBtn.parentNode.replaceChild(newApplyModifyBtn, applyModifyBtn);
      newApplyModifyBtn.addEventListener('click', () => this.applyModify());
    }

    // Style select change to show preview
    const styleSelect = document.getElementById('styleSelect');
    if (styleSelect) {
      styleSelect.addEventListener('change', () => this.showStylePreview());
    }

    this.updateGridPreviewInfo();
  }

  bindStylePanelControls() {
    const immediateControls = [
      'styleWidthMode',
      'styleCustomWidth',
      'styleMinHeight',
      'styleShadowSelect',
      'styleDarkModeToggle',
      'styleRtlToggle',
      'styleTitleSize',
      'styleBodySize',
      'styleTextColor',
      'styleAccentColor',
      'styleContentTitle',
      'styleContentDescription',
      'styleContentButton'
    ];

    immediateControls.forEach((id) => {
      const element = document.getElementById(id);
      if (!element) return;
      const eventName = element.tagName === 'SELECT' || element.type === 'checkbox' || element.type === 'color' ? 'change' : 'input';
      element.addEventListener(eventName, () => this.applyStylePanelControls());
      if (eventName !== 'change') {
        element.addEventListener('change', () => this.applyStylePanelControls());
      }
    });

    const categoryFilter = document.getElementById('styleCategoryFilter');
    if (categoryFilter) {
      categoryFilter.addEventListener('change', () => this.renderStyleSelect());
    }
  }

  getSelectedStyleSet() {
    const selectedStyleId = document.getElementById('styleSelect')?.value;
    return this.styleSets.find(s => s.id === selectedStyleId) || this.currentStyle || null;
  }

  updateStylePanelFromCurrentStyle(style = this.currentStyle) {
    if (!style) return;

    const layout = style.layout || {};
    const titleStyle = style.textStyles?.title || {};
    const descriptionStyle = style.textStyles?.description || {};
    const overrides = style.contentOverrides || {};

    const setValue = (id, value) => {
      const element = document.getElementById(id);
      if (element && value !== undefined && value !== null) {
        element.value = value;
      }
    };

    const setChecked = (id, value) => {
      const element = document.getElementById(id);
      if (element) {
        element.checked = !!value;
      }
    };

    setValue('styleWidthMode', layout.width || (layout.fullWidth ? 'full' : 'auto'));
    setValue('styleCustomWidth', layout.customWidth || this.selectedSection?.cardCustomWidth || 360);
    setValue('styleMinHeight', layout.minHeight || this.selectedSection?.sectionMinHeight || 0);
    setValue('styleShadowSelect', style.cardShadow || 'md');
    setChecked('styleDarkModeToggle', this.previewTheme === 'dark');
    setChecked('styleRtlToggle', this.previewDirection === 'rtl');
    setValue('styleTitleSize', titleStyle.fontSize || 18);
    setValue('styleBodySize', descriptionStyle.fontSize || 14);
    setValue('styleTextColor', style.cardText || titleStyle.color || '#1f2937');
    setValue('styleAccentColor', style.cardAccent || '#7c2bee');
    setValue('styleContentTitle', overrides.name || overrides.title || '');
    setValue('styleContentDescription', overrides.description || '');
    setValue('styleContentButton', overrides.button_text || overrides.button || '');
  }

  applyStylePanelControls() {
    const style = this.getSelectedStyleSet();
    if (!style) return;

    style.layout = style.layout || {};
    style.textStyles = style.textStyles || {};
    style.textStyles.title = style.textStyles.title || {};
    style.textStyles.description = style.textStyles.description || {};
    style.contentOverrides = style.contentOverrides || {};

    const widthMode = document.getElementById('styleWidthMode')?.value || 'auto';
    const customWidth = parseInt(document.getElementById('styleCustomWidth')?.value, 10) || 360;
    const minHeight = parseInt(document.getElementById('styleMinHeight')?.value, 10) || 0;
    const titleSize = parseInt(document.getElementById('styleTitleSize')?.value, 10) || style.textStyles.title.fontSize || 18;
    const bodySize = parseInt(document.getElementById('styleBodySize')?.value, 10) || style.textStyles.description.fontSize || 14;
    const textColor = document.getElementById('styleTextColor')?.value || style.cardText || '#1f2937';
    const accentColor = document.getElementById('styleAccentColor')?.value || style.cardAccent || '#7c2bee';
    const shadow = document.getElementById('styleShadowSelect')?.value || style.cardShadow || 'md';

    style.layout.width = widthMode;
    style.layout.fullWidth = widthMode === 'full';
    style.layout.customWidth = customWidth;
    style.layout.minHeight = minHeight;
    style.cardShadow = shadow;
    style.cardText = textColor;
    style.cardAccent = accentColor;
    style.textStyles.title.fontSize = titleSize;
    style.textStyles.description.fontSize = bodySize;
    style.textStyles.title.color = textColor;
    style.textStyles.description.color = textColor;

    style.contentOverrides.name = document.getElementById('styleContentTitle')?.value?.trim() || '';
    style.contentOverrides.title = style.contentOverrides.name;
    style.contentOverrides.description = document.getElementById('styleContentDescription')?.value?.trim() || '';
    style.contentOverrides.button_text = document.getElementById('styleContentButton')?.value?.trim() || '';
    style.contentOverrides.button = style.contentOverrides.button_text;

    this.previewTheme = document.getElementById('styleDarkModeToggle')?.checked ? 'dark' : 'light';
    this.previewDirection = document.getElementById('styleRtlToggle')?.checked ? 'rtl' : 'ltr';

    if (this.selectedSection) {
      this.selectedSection.cardWidthMode = widthMode;
      this.selectedSection.cardCustomWidth = customWidth;
      this.selectedSection.sectionFullWidth = widthMode === 'full';
      this.selectedSection.sectionMinHeight = minHeight;
    }

    this.currentStyle = style;
    this.showStylePreview();
    this.renderPreview();
    this.saveData();
  }

  applyGridConfig() {
    this.updateGridConfigFromControls();

    console.log('=== Applying Grid Config ===');
    console.log('Grid config:', this.gridConfig);

    const existingGridSection = this.sections.find(s => s.gridEnabled);
    console.log('Existing grid section:', existingGridSection ? 'Yes' : 'No');

    if (!existingGridSection) {
      const gridSection = {
        id: Date.now(),
        name: 'Grid Section',
        content: '',
        className: 'grid-section',
        visible: true,
        gridEnabled: true,
        gridColumns: this.gridConfig.columns,
        gridColumnsDesktop: this.gridConfig.columnsDesktop,
        gridColumnsTablet: this.gridConfig.columnsTablet,
        gridColumnsPhone: this.gridConfig.columnsPhone,
        gridGap: this.gridConfig.gap,
        gridMinWidth: this.gridConfig.minWidth,
        gridMaxWidth: this.gridConfig.maxWidth,
        gridSectionPadding: this.gridConfig.sectionPadding,
        gridCardLimit: this.gridConfig.cardLimit,
        showPlaceholders: this.gridConfig.showPlaceholders,
        styleApplied: false,
        styleSetId: null
      };
      console.log('Creating new grid section, ID:', gridSection.id);
      this.sections.push(gridSection);
    } else {
      console.log('Updating existing grid section, ID:', existingGridSection.id);
      existingGridSection.gridColumns = this.gridConfig.columns;
      existingGridSection.gridColumnsDesktop = this.gridConfig.columnsDesktop;
      existingGridSection.gridColumnsTablet = this.gridConfig.columnsTablet;
      existingGridSection.gridColumnsPhone = this.gridConfig.columnsPhone;
      existingGridSection.gridGap = this.gridConfig.gap;
      existingGridSection.gridMinWidth = this.gridConfig.minWidth;
      existingGridSection.gridMaxWidth = this.gridConfig.maxWidth;
      existingGridSection.gridSectionPadding = this.gridConfig.sectionPadding;
      existingGridSection.gridCardLimit = this.gridConfig.cardLimit;
      existingGridSection.showPlaceholders = this.gridConfig.showPlaceholders;
      console.log('Updated grid section:', existingGridSection);
    }

    this.selectedSection = this.sections.find(s => s.gridEnabled);
    console.log('Selected section:', this.selectedSection?.name, 'ID:', this.selectedSection?.id);
    console.log('Sections count:', this.sections.length);

    this.renderSections();
    this.renderPreview();
    this.updateGridPreviewInfo();
    this.showToast('Grid configuration applied', 'success');
  }

  applyModify() {
    // Apply spacing/padding modifications only to the selected grid section
    if (!this.selectedSection || !this.selectedSection.gridEnabled) {
      this.showToast('Please select a grid section first', 'error');
      return;
    }

    this.updateGridConfigFromControls();

    console.log('=== Applying Modify (Spacing/Padding) ===');
    console.log('Selected section ID:', this.selectedSection.id);
    console.log('Updating gap and padding');

    // Update only spacing/padding values
    this.selectedSection.gridGap = this.gridConfig.gap;
    this.selectedSection.gridSectionPadding = this.gridConfig.sectionPadding;
    this.selectedSection.gridMinWidth = this.gridConfig.minWidth;
    this.selectedSection.gridMaxWidth = this.gridConfig.maxWidth;

    console.log('Updated section:', {
      gap: this.selectedSection.gridGap,
      sectionPadding: this.selectedSection.gridSectionPadding,
      minWidth: this.selectedSection.gridMinWidth,
      maxWidth: this.selectedSection.gridMaxWidth
    });

    this.renderPreview();
    this.saveData();
    this.showToast('Spacing/padding modified', 'success');
  }

  bindStyleControls() {
    const cardRadius = document.getElementById('cardRadius');
    const cardPadding = document.getElementById('cardPadding');
    
    if (cardRadius) {
      cardRadius.addEventListener('input', (e) => {
        const radiusValue = document.getElementById('cardRadiusValue');
        if (radiusValue) radiusValue.textContent = e.target.value;
        this.updatePreviewFromControls();
      });
    }
    
    if (cardPadding) {
      cardPadding.addEventListener('input', (e) => {
        const paddingValue = document.getElementById('cardPaddingValue');
        if (paddingValue) paddingValue.textContent = e.target.value;
        this.updatePreviewFromControls();
      });
    }
    
    ['cardBg', 'cardText', 'cardBorder', 'cardAccent', 'cardShadow'].forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', () => {
          this.updatePreviewFromControls();
        });
      }
    });
  }

  updateGridPreviewInfo() {
    const desktopCols = parseInt(document.getElementById('gridColumnsDesktop')?.value) || 4;
    const tabletCols = parseInt(document.getElementById('gridColumnsTablet')?.value) || 2;
    const phoneCols = parseInt(document.getElementById('gridColumnsPhone')?.value) || 1;
    const cardLimit = parseInt(document.getElementById('gridCardLimitNum')?.value) || 0;
    
    const previewText = document.getElementById('gridPreviewText');
    if (previewText) {
      previewText.textContent = `Desktop: ${desktopCols} cols, Tablet: ${tabletCols} cols, Phone: ${phoneCols} col${phoneCols > 1 ? 's' : ''}`;
    }
    
    const cardsText = document.getElementById('gridCardsText');
    if (cardsText) {
      const dataCount = this.sheetData.length;
      const displayCount = cardLimit > 0 ? Math.min(dataCount, cardLimit) : dataCount;
      cardsText.textContent = `${displayCount} of ${dataCount} cards ${cardLimit > 0 ? '(limited)' : '(all)'}`;
    }
  }

  showStylePreview() {
    const styleSelect = document.getElementById('styleSelect');
    const selectedStyleId = styleSelect?.value;
    
    if (!selectedStyleId) {
      document.getElementById('stylePreviewCard').style.display = 'none';
      return;
    }
    
    const style = this.styleSets.find(s => s.id === selectedStyleId);
    if (!style) {
      document.getElementById('stylePreviewCard').style.display = 'none';
      return;
    }
    
    this.currentStyle = style;
    this.updateStylePanelFromCurrentStyle(style);
    
    // Show preview card
    document.getElementById('stylePreviewCard').style.display = 'block';
    
    // Use first available card data
    if (this.sheetData.length > 0) {
      this.selectedCard = {
        index: 0,
        data: this.sheetData[0]
      };
      
      // Update preview info with card name
      const nameEl = document.getElementById('stylePreviewName');
      if (nameEl) {
        const cardName = this.sheetData[0].name || this.sheetData[0].title || 'Card 1';
        nameEl.textContent = `${style.name || 'Unknown Style'} - Selected: ${cardName}`;
      }
      
      // Render actual card preview
      const imageEl = document.getElementById('stylePreviewImage');
      if (imageEl) {
        const cardHtml = this.renderCard(this.sheetData[0]);
        imageEl.innerHTML = `<div class="card" style="
          width: 100%;
          height: 100%;
          transform: scale(0.95);
          background: ${style.cardBg || '#fff'};
          border-radius: ${style.cardRadius || 8}px;
          padding: ${style.cardPadding || 16}px;
          overflow: auto;
        ">${cardHtml}</div>`;
      }
    } else {
      // No data available, show style info and thumbnail or placeholder
      const nameEl = document.getElementById('stylePreviewName');
      if (nameEl) {
        nameEl.textContent = `${style.name || 'Unknown Style'} - ${style.description || ''}`;
      }
      
      // Show thumbnail if available, otherwise show placeholder
      const imageEl = document.getElementById('stylePreviewImage');
      if (imageEl) {
        if (style.thumbnail) {
          imageEl.innerHTML = `<img src="${style.thumbnail}" style="width: 100%; height: 100%; object-fit: cover;" alt="${style.name}" onerror="this.outerHTML='<div style=\\'width:100%;height:100%;background:#f3f4f6;display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:14px\\'>No Image</div>'">`;
        } else {
          imageEl.innerHTML = `<div style="width:100%;height:100%;background:linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:14px;">No Preview</div>`;
        }
      }
    }
    
    // Update columns info
    const colsEl = document.getElementById('stylePreviewCols');
    if (colsEl) {
      const cols = style.grid?.columns || 4;
      colsEl.textContent = `${cols} columns`;
    }
    
    // Update fields info
    const fieldsEl = document.getElementById('stylePreviewFields');
    if (fieldsEl) {
      const fields = [];
      if (style.data_binding) {
        Object.keys(style.data_binding).forEach(key => {
          fields.push(key);
        });
      } else if (this.sheetData.length > 0) {
        fields.push(...Object.keys(this.sheetData[0]));
      }
      fieldsEl.textContent = fields.length > 0 ? fields.join(', ') : 'No fields defined';
    }
  }

  updateGridConfigFromControls() {
    // Get responsive column values
    const desktopCols = parseInt(document.getElementById('gridColumnsDesktop')?.value) || 4;
    const tabletCols = parseInt(document.getElementById('gridColumnsTablet')?.value) || 2;
    const phoneCols = parseInt(document.getElementById('gridColumnsPhone')?.value) || 1;
    
    this.gridConfig.columns = desktopCols; // Default to desktop
    this.gridConfig.columnsDesktop = desktopCols;
    this.gridConfig.columnsTablet = tabletCols;
    this.gridConfig.columnsPhone = phoneCols;
    
    this.gridConfig.gap = parseInt(document.getElementById('gridGapNum')?.value) || 24;
    this.gridConfig.minWidth = parseInt(document.getElementById('gridMinWidthNum')?.value) || 280;
    this.gridConfig.maxWidth = parseInt(document.getElementById('gridMaxWidthNum')?.value) || 1440;
    this.gridConfig.sectionPadding = parseInt(document.getElementById('gridSectionPadding')?.value) || 40;
    this.gridConfig.showPlaceholders = document.getElementById('showPlaceholders')?.checked !== false;
    
    const explicitCardLimit = parseInt(document.getElementById('gridCardLimitNum')?.value) || 0;
    this.gridConfig.cardLimit = explicitCardLimit;

    const gridSection = this.sections.find(s => s.gridEnabled);
    if (gridSection) {
      gridSection.gridColumns = desktopCols;
      gridSection.gridColumnsDesktop = desktopCols;
      gridSection.gridColumnsTablet = tabletCols;
      gridSection.gridColumnsPhone = phoneCols;
      gridSection.gridGap = this.gridConfig.gap;
      gridSection.gridMinWidth = this.gridConfig.minWidth;
      gridSection.gridMaxWidth = this.gridConfig.maxWidth;
      gridSection.gridSectionPadding = this.gridConfig.sectionPadding;
      gridSection.gridCardLimit = this.gridConfig.cardLimit;
      gridSection.showPlaceholders = this.gridConfig.showPlaceholders;
      console.log('Updated grid section config:', gridSection);
    }
  }

  syncGridControls(section) {
    if (!section || !section.gridEnabled) return;

    console.log('Syncing grid controls with section:', section.id);

    // Sync responsive columns
    if (document.getElementById('gridColumnsDesktop')) {
      document.getElementById('gridColumnsDesktop').value = section.gridColumnsDesktop || section.gridColumns || 4;
    }
    if (document.getElementById('gridColumnsTablet')) {
      document.getElementById('gridColumnsTablet').value = section.gridColumnsTablet || 2;
    }
    if (document.getElementById('gridColumnsPhone')) {
      document.getElementById('gridColumnsPhone').value = section.gridColumnsPhone || 1;
    }
    
    if (document.getElementById('gridGapNum')) {
      document.getElementById('gridGapNum').value = section.gridGap || 24;
    }
    if (document.getElementById('gridMinWidthNum')) {
      document.getElementById('gridMinWidthNum').value = section.gridMinWidth || 280;
    }
    if (document.getElementById('gridMaxWidthNum')) {
      document.getElementById('gridMaxWidthNum').value = section.gridMaxWidth || 1440;
    }
    if (document.getElementById('gridSectionPadding')) {
      document.getElementById('gridSectionPadding').value = section.gridSectionPadding || 40;
    }
    if (document.getElementById('gridCardLimitNum')) {
      document.getElementById('gridCardLimitNum').value = section.gridCardLimit ?? 0;
    }
    if (document.getElementById('showPlaceholders')) {
      document.getElementById('showPlaceholders').checked = section.showPlaceholders !== false;
    }

    this.updateGridPreviewInfo();
  }

  updatePreviewFromControls() {
    if (!this.currentStyle) {
      this.currentStyle = {
        id: Date.now(),
        name: 'Custom Style',
        cardBg: document.getElementById('cardBg').value,
        cardText: document.getElementById('cardText').value,
        cardBorder: document.getElementById('cardBorder').value,
        cardAccent: document.getElementById('cardAccent').value,
        cardRadius: parseInt(document.getElementById('cardRadius').value),
        cardPadding: parseInt(document.getElementById('cardPadding').value),
        cardShadow: document.getElementById('cardShadow').value
      };
    } else {
      this.currentStyle.cardBg = document.getElementById('cardBg').value;
      this.currentStyle.cardText = document.getElementById('cardText').value;
      this.currentStyle.cardBorder = document.getElementById('cardBorder').value;
      this.currentStyle.cardAccent = document.getElementById('cardAccent').value;
      this.currentStyle.cardRadius = parseInt(document.getElementById('cardRadius').value);
      this.currentStyle.cardPadding = parseInt(document.getElementById('cardPadding').value);
      this.currentStyle.cardShadow = document.getElementById('cardShadow').value;
    }
    this.renderPreview();
  }

  switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });
    document.querySelectorAll('.panel').forEach(panel => {
      panel.classList.toggle('active', panel.id === tabName + '-panel');
    });
  }

  newProject() {
    if (confirm('Are you sure you want to create a new project? All unsaved changes will be lost.')) {
      this.sections = [];
      this.sheetData = [];
      this.selectedSection = null;
      this.currentStyle = null;
      this.renderSections();
      this.renderPreview();
      this.showToast('New project created', 'success');
    }
  }

  clearStorage() {
    if (confirm('Clear all saved data and reload? This cannot be undone.')) {
      localStorage.clear();
      sessionStorage.clear();
      indexedDB.deleteDatabase('SheetCache');
      this.showToast('Storage cleared. Reloading...', 'success');
      setTimeout(() => location.reload(), 1000);
    }
  }

  importHtml() {
    document.getElementById('fileInput').click();
  }

  handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const html = e.target.result;
      this.parseHtml(html);
    };
    reader.readAsText(file);
    event.target.value = '';
  }

  parseHtml(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    this.originalHead = doc.head.innerHTML;
    this.originalHtmlClass = doc.documentElement.className;

    this.detectContainerWidth(doc);

    const importedSections = this.extractSectionsFromDocument(doc, html)
      .map(section => this.createSectionData(section.name, section.content, section.className));

    if (importedSections.length === 0) {
      importedSections.push(this.createSectionData('Full Page', html));
    }

    this.sections.push(...importedSections);
    this.selectedSection = importedSections[importedSections.length - 1] || this.selectedSection;

    this.renderSections();
    this.renderPreview();
    this.saveData();
    this.showToast(`成功导入 ${importedSections.length} 个区块`, 'success');
  }

  extractSectionsFromDocument(doc, originalHtml = '') {
    const sourceNodes = this.expandImportNodes(this.getImportSourceNodes(doc.body));

    if (sourceNodes.length === 0) {
      return originalHtml ? [{ name: 'Full Page', content: originalHtml, className: '' }] : [];
    }

    const sections = [];
    let pendingSectionName = '';

    sourceNodes.forEach((node) => {
      if (node.nodeType === Node.COMMENT_NODE) {
        const commentName = this.extractSectionNameFromComment(node.textContent || '');
        if (commentName) {
          pendingSectionName = commentName;
        }
        return;
      }

      if (node.nodeType !== Node.ELEMENT_NODE || this.isIgnoredImportElement(node)) {
        return;
      }

      const sectionName = pendingSectionName || this.getSectionNameFromElement(node, sections.length + 1);
      sections.push({
        name: sectionName,
        content: node.outerHTML,
        className: node.className || ''
      });
      pendingSectionName = '';
    });

    return sections;
  }

  expandImportNodes(nodes, depth = 0) {
    if (!Array.isArray(nodes) || nodes.length === 0 || depth >= 2) {
      return nodes;
    }

    const expandedNodes = [];

    nodes.forEach((node) => {
      if (node.nodeType !== Node.ELEMENT_NODE) {
        expandedNodes.push(node);
        return;
      }

      if (this.shouldExpandImportNode(node, nodes)) {
        const childNodes = this.getMeaningfulImportNodes(node);
        const normalizedChildren = this.expandImportNodes(childNodes, depth + 1);

        if (normalizedChildren.length > 0) {
          expandedNodes.push(...normalizedChildren);
          return;
        }
      }

      expandedNodes.push(node);
    });

    return expandedNodes;
  }

  getImportSourceNodes(container, depth = 0) {
    const nodes = this.getMeaningfulImportNodes(container);
    const elementNodes = nodes.filter(node => node.nodeType === Node.ELEMENT_NODE);

    if (elementNodes.length !== 1 || depth >= 3) {
      return nodes;
    }

    const [singleElement] = elementNodes;
    if (!this.shouldUnwrapImportContainer(singleElement)) {
      return nodes;
    }

    return this.getImportSourceNodes(singleElement, depth + 1);
  }

  getMeaningfulImportNodes(container) {
    return Array.from(container.childNodes).filter(node => {
      if (node.nodeType === Node.TEXT_NODE) {
        return node.textContent.trim().length > 0;
      }

      if (node.nodeType === Node.COMMENT_NODE) {
        return node.textContent.trim().length > 0;
      }

      return node.nodeType === Node.ELEMENT_NODE && !this.isIgnoredImportElement(node);
    });
  }

  isIgnoredImportElement(element) {
    const ignoredTags = ['script', 'style', 'meta', 'link', 'noscript', 'template'];
    return ignoredTags.includes(element.tagName.toLowerCase());
  }

  shouldUnwrapImportContainer(element) {
    const tagName = element.tagName.toLowerCase();
    const childElements = this.getMeaningfulImportNodes(element)
      .filter(node => node.nodeType === Node.ELEMENT_NODE);

    if (childElements.length === 0) {
      return false;
    }

    if (tagName === 'main') {
      return childElements.length >= 1;
    }

    if (tagName !== 'div') {
      return false;
    }

    const hasSemanticChild = childElements.some(child => /^(header|nav|main|section|article|footer|aside)$/i.test(child.tagName));
    const wrapperHint = `${element.id || ''} ${element.className || ''}`.toLowerCase();
    const looksLikePageWrapper = /(app|page|layout|wrapper|root|shell|site)/.test(wrapperHint);

    return childElements.length >= 3 || hasSemanticChild || looksLikePageWrapper;
  }

  shouldExpandImportNode(element, siblingNodes = []) {
    if (this.isBackgroundLikeElement(element)) {
      return false;
    }

    const tagName = element.tagName.toLowerCase();
    if (tagName === 'main') {
      return true;
    }

    if (tagName !== 'div') {
      return false;
    }

    const childNodes = this.getMeaningfulImportNodes(element);
    const childElements = childNodes.filter(node => node.nodeType === Node.ELEMENT_NODE);
    if (childElements.length < 2) {
      return false;
    }

    const semanticChildren = childElements.filter(child => /^(header|nav|main|section|article|footer|aside)$/i.test(child.tagName));
    const siblingElements = siblingNodes.filter(node => node.nodeType === Node.ELEMENT_NODE);
    const hasBackgroundSibling = siblingElements.some(node => node !== element && this.isBackgroundLikeElement(node));
    const wrapperHint = `${element.id || ''} ${element.className || ''}`.toLowerCase();
    const looksLikePageWrapper = /(app|page|layout|wrapper|root|shell|site|max-w|container)/.test(wrapperHint);

    return semanticChildren.length >= 2 || (hasBackgroundSibling && (semanticChildren.length >= 1 || looksLikePageWrapper));
  }

  isBackgroundLikeElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }

    const tagName = element.tagName.toLowerCase();
    const hint = `${element.id || ''} ${element.className || ''} ${element.getAttribute('data-us-project') || ''}`.toLowerCase();
    const style = (element.getAttribute('style') || '').toLowerCase();

    if (tagName === 'canvas') {
      return true;
    }

    return /(background|backdrop|particle|unicorn|aura-background)/.test(hint)
      || style.includes('mask-image')
      || style.includes('-webkit-mask-image');
  }

  extractSectionNameFromComment(commentText) {
    const cleanedText = commentText.trim();
    const sectionMatch = cleanedText.match(/(?:Section|区域|模块|Block)\s*(?:\d+)?\s*[:：-]\s*(.+)/i);

    if (sectionMatch?.[1]) {
      return sectionMatch[1].trim();
    }

    const numberedMatch = cleanedText.match(/^\d+\s*[.、:-]\s*(.+)$/);
    if (numberedMatch?.[1]) {
      return this.formatSectionLabel(numberedMatch[1]);
    }

    const shotMatch = cleanedText.match(/^(?:shot|scene|step)\s*\d+\s*[:：-]\s*(.+)$/i);
    if (shotMatch?.[1]) {
      return this.formatSectionLabel(shotMatch[1]);
    }

    const backgroundMatch = cleanedText.match(/^(background)(?:\s*\((.+)\))?/i);
    if (backgroundMatch) {
      return backgroundMatch[2]
        ? `Background / ${this.formatSectionLabel(backgroundMatch[2])}`
        : 'Background';
    }

    if (/^(nav|header|hero|features|pricing|testimonials|faq|footer)$/i.test(cleanedText)) {
      return this.formatSectionLabel(cleanedText);
    }

    return '';
  }

  getSectionNameFromElement(element, index) {
    const tagName = element.tagName.toLowerCase();
    const heading = element.querySelector('h1, h2, h3, h4, h5, h6');
    const headingText = heading?.textContent?.trim();

    if (tagName === 'header' || tagName === 'nav') {
      return 'Header / Navigation';
    }

    if (tagName === 'footer') {
      return 'Footer';
    }

    if (tagName === 'main') {
      return 'Main Content';
    }

    if (tagName === 'aside') {
      return 'Sidebar';
    }

    if (headingText) {
      return headingText.length > 48 ? `${headingText.slice(0, 45)}...` : headingText;
    }

    const labelSource = element.getAttribute('data-section-name') || element.getAttribute('aria-label') || element.id || element.className;
    if (labelSource) {
      return this.formatSectionLabel(labelSource);
    }

    if (tagName === 'section' || tagName === 'article') {
      return `Section ${index}`;
    }

    return `Block ${index}`;
  }

  formatSectionLabel(rawLabel) {
    const normalized = String(rawLabel)
      .split(/\s+/)
      .find(Boolean) || String(rawLabel);

    return normalized
      .replace(/[-_]+/g, ' ')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, char => char.toUpperCase());
  }

  detectContainerWidth(doc) {
    const commonContainers = doc.querySelectorAll('.container, .wrapper, .content, main, section, [class*="container"], [class*="wrapper"], [class*="content"]');
    
    let detectedWidth = null;
    const computedWidths = [];
    
    commonContainers.forEach(el => {
      const style = el.style;
      const classList = el.classList;
      
      if (style.maxWidth) {
        const widthMatch = style.maxWidth.match(/(\d+)/);
        if (widthMatch) {
          computedWidths.push(parseInt(widthMatch[1]));
        }
      }
      
      if (style.width) {
        const widthMatch = style.width.match(/(\d+)/);
        if (widthMatch) {
          computedWidths.push(parseInt(widthMatch[1]));
        }
      }
      
      classList.forEach(cls => {
        const widthMatch = cls.match(/container-(\d+)/);
        if (widthMatch) {
          computedWidths.push(parseInt(widthMatch[1]));
        }
      });
    });
    
    const styleSheets = doc.querySelectorAll('style');
    styleSheets.forEach(sheet => {
      const cssText = sheet.textContent;
      const containerMatches = cssText.match(/\.container[^{]*{[^}]*max-width:\s*(\d+)/g);
      if (containerMatches) {
        containerMatches.forEach(match => {
          const widthMatch = match.match(/max-width:\s*(\d+)/);
          if (widthMatch) {
            computedWidths.push(parseInt(widthMatch[1]));
          }
        });
      }
    });
    
    if (computedWidths.length > 0) {
      const widths = computedWidths.filter(w => w > 300 && w < 2000);
      if (widths.length > 0) {
        this.detectedContainerWidth = Math.max(...widths);
      }
    }
    
    if (!this.detectedContainerWidth) {
      this.detectedContainerWidth = 1200;
    }
    
    this.gridConfig.maxWidth = this.detectedContainerWidth;
    
    const maxWidthInput = document.getElementById('gridMaxWidth');
    const maxWidthNumInput = document.getElementById('gridMaxWidthNum');
    if (maxWidthInput) maxWidthInput.value = this.detectedContainerWidth;
    if (maxWidthNumInput) maxWidthNumInput.value = this.detectedContainerWidth;
  }

  addSection(name = 'New Section', content = '', className = '') {
    const section = this.createSectionData(name, content, className);
    this.sections.push(section);
    this.selectedSection = section;
    this.renderSections();
    this.renderPreview();
    this.saveData();
    this.showToast('Section added: ' + name, 'success');
    return section;
  }

  createSectionData(name = 'New Section', content = '', className = '') {
    return {
      id: this.generateSectionId(),
      name,
      content,
      className,
      visible: true,
      gridEnabled: false,
      gridColumns: 3,
      styleApplied: false,
      styleSetId: null
    };
  }

  generateSectionId() {
    return Date.now() * 1000 + Math.floor(Math.random() * 1000);
  }

  deleteSection(id) {
    if (confirm('Are you sure you want to delete this section?')) {
      this.sections = this.sections.filter(s => s.id !== id);
      if (this.selectedSection && this.selectedSection.id === id) {
        this.selectedSection = null;
      }
      this.renderSections();
      this.renderPreview();
      this.saveData();
      this.showToast('Section deleted', 'success');
    }
  }

  selectSection(id) {
    this.selectedSection = this.sections.find(s => s.id === id);
    if (this.selectedSection && this.selectedSection.gridEnabled) {
      document.getElementById('gridColumns').value = this.selectedSection.gridColumns;
      document.getElementById('gridColumnsNum').value = this.selectedSection.gridColumns;
      document.getElementById('gridGap').value = this.selectedSection.gridGap;
      document.getElementById('gridGapNum').value = this.selectedSection.gridGap;
      document.getElementById('gridMinWidth').value = this.selectedSection.gridMinWidth;
      document.getElementById('gridMinWidthNum').value = this.selectedSection.gridMinWidth;
      document.getElementById('gridMaxWidth').value = this.selectedSection.gridMaxWidth;
      document.getElementById('gridMaxWidthNum').value = this.selectedSection.gridMaxWidth;
      document.getElementById('gridCardLimitNum').value = this.selectedSection.gridCardLimit ?? 0;
      this.updateGridConfigFromControls();
    }
    // If selected is a Tally section, populate Tally panel inputs for editing config
    if (this.selectedSection && this.selectedSection.type === 'tally') {
      const cfg = this.selectedSection.config || {};
      
      // Only populate the config fields (width and padding)
      // Don't change URL/embedCode fields - user might want to add another Tally
      const widthInput = document.getElementById('tallyWidth');
      if (widthInput) widthInput.value = cfg.width || 1200;
      const top = document.getElementById('tallyPaddingTop');
      const bottom = document.getElementById('tallyPaddingBottom');
      const left = document.getElementById('tallyPaddingLeft');
      const right = document.getElementById('tallyPaddingRight');
      if (top) top.value = cfg.padding?.top ?? 60;
      if (bottom) bottom.value = cfg.padding?.bottom ?? 60;
      if (left) left.value = cfg.padding?.left ?? 20;
      if (right) right.value = cfg.padding?.right ?? 20;
    }
    this.renderSections();
    this.showToast('Section selected: ' + this.selectedSection.name, 'success');
  }

  editSection(id) {
    const section = this.sections.find(s => s.id === id);
    if (!section) return;

    const newName = prompt('Section Name:', section.name);
    if (newName !== null) {
      section.name = newName;
      this.renderSections();
      this.saveData();
    }
  }

  toggleSectionVisibility(id) {
    const section = this.sections.find(s => s.id === id);
    if (section) {
      section.visible = !section.visible;
      this.renderSections();
      this.renderPreview();
      this.saveData();
    }
  }

  renderSections() {
    const container = document.getElementById('sectionList');
    
    if (this.sections.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="12" y1="8" x2="12" y2="16"/>
            <line x1="8" y1="12" x2="16" y2="12"/>
          </svg>
          <h3>No Sections</h3>
          <p>Import HTML or add new sections</p>
        </div>
      `;
      return;
    }

    container.innerHTML = this.sections.map(section => {
      const styleSet = section.styleSetId ? this.styleSets.find(s => s.id === section.styleSetId) : null;
      
      let typeBadge = '';
      if (section.type === 'tally') {
        typeBadge = `<span class="type-badge" style="background: #10b981; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">Tally Form</span>`;
      }
      
      let imagePreview = '';
      if (section.gridEnabled && this.sheetData.length > 0) {
        console.log('=== Rendering Image Preview ===');
        console.log('Sheet data count:', this.sheetData.length);
        console.log('First item:', this.sheetData[0]);
        
        const firstItem = this.sheetData[0];
        const imageUrl = this.findImageUrl(firstItem);
        console.log('Image URL found:', imageUrl);
        
        if (imageUrl) {
          const previewImages = this.sheetData.slice(0, 3).map((item, idx) => {
            const url = this.findImageUrl(item);
            console.log(`Preview image ${idx}:`, url);
            if (!url) return '';
            return `<img src="${url}" style="
              width: 40px;
              height: 40px;
              border-radius: 4px;
              object-fit: cover;
              flex-shrink: 0;
              border: 1px solid #e5e7eb;
            " onerror="console.error('Failed to load image:', this.src); this.outerHTML='<div style=\'width:40px;height:40px;border-radius:4px;background:#f3f4f6;display:flex;align-items:center;justify-content:center;font-size:10px;color:#9ca3af\'>?</div>'">`;
          }).join('');
          
          imagePreview = `
            <div class="section-image-preview" style="
              margin-top: 8px;
              display: flex;
              gap: 8px;
              overflow-x: auto;
              padding-bottom: 4px;
            ">
              ${previewImages}
            </div>
          `;
          console.log('Image preview HTML length:', imagePreview.length);
        } else {
          console.log('No image URL found, skipping preview');
        }
      }
      
      return `
      <div class="section-item ${this.selectedSection && this.selectedSection.id === section.id ? 'selected' : ''} ${!section.visible ? 'opacity-50' : ''}"
           data-id="${section.id}">
        <div class="section-item-header">
          <span class="section-item-title">${section.name}</span>
          <div class="section-item-actions">
            <button class="btn btn-secondary" onclick="editor.toggleSectionVisibility(${section.id})">
              ${section.visible ? 'Hide' : 'Show'}
            </button>
            <button class="btn btn-secondary" onclick="editor.editSection(${section.id})">Edit</button>
            <button class="btn btn-secondary" onclick="editor.deleteSection(${section.id})">Delete</button>
          </div>
        </div>
        <div class="section-item-preview">
          ${section.className || 'No Class'}
          ${typeBadge}
          ${section.gridEnabled ? `
            <span class="grid-badge" style="background: #3b82f6; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">
              Grid: ${section.gridColumns || 3} cols
            </span>
          ` : ''}
          ${section.styleApplied ? `<span class="style-badge" style="background: #7c2bee; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-left: 8px;">${styleSet ? styleSet.name : 'Style Applied'}</span>` : ''}
        </div>
        ${imagePreview}
      </div>
    `;
    }).join('');

    container.querySelectorAll('.section-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (!e.target.closest('button')) {
          this.selectSection(parseInt(item.dataset.id));
        }
      });
    });

    this.makeSectionsSortable();
  }

  makeSectionsSortable() {
    const container = document.getElementById('sectionList');
    new Sortable(container, {
      animation: 150,
      handle: '.section-item',
      onEnd: (evt) => {
        const item = this.sections.splice(evt.oldIndex, 1)[0];
        this.sections.splice(evt.newIndex, 0, item);
        this.saveData();
        this.renderPreview();
      }
    });
  }

  async loadSheetData() {
    const url = document.getElementById('sheetUrl').value.trim();
    const sheetName = document.getElementById('sheetName').value.trim() || 'Sheet1';

    if (!url) {
      this.showToast('Please enter Google Sheets URL', 'error');
      return;
    }

    try {
      const btn = document.getElementById('loadDataBtn');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span class="loading">Loading...</span>';
      btn.disabled = true;

      const result = await this.connector.loadSheetData(url, sheetName, {
        useCache: true,
        cacheTimeout: 5 * 60 * 1000,
        showWarnings: true
      });

      console.log('=== Load Sheet Data Result ===');
      console.log('Result:', result);
      console.log('Result.data:', result?.data);

      if (!result || !result.data) {
        throw new Error('No data returned from connector');
      }

      this.sheetData = Array.isArray(result.data) ? result.data : [];
      
      if (this.sheetData.length === 0) {
        this.showToast('No data found. Please check Google Sheets URL and sheet name', 'warning');
      } else {
        this.showToast(`Successfully loaded ${this.sheetData.length} records`, 'success');
        
        console.log('=== Sheet Data Loaded ===');
        console.log('Total rows:', this.sheetData.length);

        const hasGridSection = this.sections.some(s => s.gridEnabled);

        if (!hasGridSection) {
          console.log('Creating new grid section...');
          const gridSection = {
            id: Date.now(),
            name: 'Data Grid Section',
            content: '',
            className: 'grid-section',
            visible: true,
            gridEnabled: true,
            gridColumns: this.gridConfig.columns,
            gridColumnsDesktop: this.gridConfig.columnsDesktop || 4,
            gridColumnsTablet: this.gridConfig.columnsTablet || 2,
            gridColumnsPhone: this.gridConfig.columnsPhone || 1,
            gridGap: this.gridConfig.gap,
            gridMinWidth: this.gridConfig.minWidth,
            gridMaxWidth: this.gridConfig.maxWidth,
            gridSectionPadding: this.gridConfig.sectionPadding || 40,
            gridCardLimit: this.gridConfig.cardLimit || 0,
            showPlaceholders: this.gridConfig.showPlaceholders !== false,
            styleApplied: false,
            styleSetId: null
          };
          this.sections.push(gridSection);
          this.selectedSection = gridSection;
          console.log('Grid section created, ID:', gridSection.id);
        } else {
          console.log('Using existing grid section');
        }
      }

      this.renderDataPreview();
      this.renderSections();
      this.renderPreview();
      this.updateGridPreviewInfo();

    } catch (error) {
      this.showToast('Failed to load data: ' + error.message, 'error');
    } finally {
      const btn = document.getElementById('loadDataBtn');
      btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M8 2L3 7h2v7h6V7h2L8 2z"/></svg>Load Data';
      btn.disabled = false;
    }
  }

  async clearCache() {
    try {
      await this.connector.clearCache();
      this.showToast('Cache cleared successfully', 'success');
      console.log('Cache cleared');
    } catch (error) {
      this.showToast('Failed to clear cache: ' + error.message, 'error');
      console.error('Failed to clear cache:', error);
    }
  }

  renderDataPreview() {
    const container = document.getElementById('dataPreview');
    
    if (!this.sheetData || this.sheetData.length === 0) {
      container.innerHTML = '<p style="color: #6b7280; font-size: 14px;">No data</p>';
      return;
    }

    const headers = Object.keys(this.sheetData[0]);
    const rows = this.sheetData.slice(0, 10);

    container.innerHTML = `
      <table class="data-table">
        <thead>
          <tr>
            ${headers.map(h => `<th>${h}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${rows.map(row => `
            <tr>
              ${headers.map(h => `<td>${row[h] || ''}</td>`).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
      ${this.sheetData.length > 10 ? `<p style="margin-top: 12px; color: #6b7280; font-size: 12px;">Showing first 10 of ${this.sheetData.length} records</p>` : ''}
    `;
  }

  saveStyleSet() {
    const name = document.getElementById('styleSetName').value.trim();
    if (!name) {
      this.showToast('Please enter style set name', 'error');
      return;
    }

    const styleSet = {
      id: Date.now(),
      name,
      cardBg: document.getElementById('cardBg').value,
      cardText: document.getElementById('cardText').value,
      cardBorder: document.getElementById('cardBorder').value,
      cardAccent: document.getElementById('cardAccent').value,
      cardRadius: parseInt(document.getElementById('cardRadius').value),
      cardPadding: parseInt(document.getElementById('cardPadding').value),
      cardShadow: document.getElementById('cardShadow').value
    };

    this.styleSets.push(styleSet);
    this.currentStyle = styleSet;
    this.renderStyleCategoryOptions();
    this.renderStyleSelect();
    this.renderStyleSets();
    this.renderPreview();
    this.saveData();
    this.showToast('Style set saved', 'success');
  }

  importStyleSet() {
    document.getElementById('styleFileInput').click();
  }

  handleStyleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const styleData = JSON.parse(e.target.result);

        const styleSet = {
          id: styleData.id || Date.now() + Math.random(),
          name: styleData.name || file.name.replace('.json', ''),
          description: styleData.description || '',
          cardBg: styleData.cardBg || styleData.cardStyle?.bg || '#ffffff',
          cardText: styleData.cardText || styleData.cardStyle?.text || '#1f2937',
          cardBorder: styleData.cardBorder || styleData.cardStyle?.border || '#e5e7eb',
          cardAccent: styleData.cardAccent || styleData.fields?.price?.color || '#7c2bee',
          cardRadius: styleData.cardRadius || styleData.cardStyle?.radius || 12,
          cardPadding: styleData.cardPadding || styleData.cardStyle?.padding || 16,
          cardShadow: styleData.cardShadow || styleData.cardStyle?.shadow || 'md',
          fields: styleData.fields || {},
          hover: styleData.hover || {},
          template: styleData.template || null,
          grid: styleData.grid || null,
          dataMapping: styleData.dataMapping || null,
          textStyles: styleData.textStyles || {},
          animation: styleData.animation || { enabled: false },
          isNewFormat: styleData.template && (styleData.template.html || styleData.template.css)
        };

        this.styleSets.push(styleSet);
        this.currentStyle = styleSet;
        this.renderStyleCategoryOptions();
        this.renderStyleSelect();
        this.renderStyleSets();
        this.renderPreview();
        this.saveData();
        this.showToast('Style set imported: ' + styleSet.name, 'success');
      } catch (error) {
        console.error('Failed to import style set:', error);
        this.showToast('Failed to import style set. Please check the file format.', 'error');
      }
    };
    reader.readAsText(file);

    event.target.value = '';
  }

  loadFromStyleFolder() {
    const styleFiles = [
      'STYLE_SET_TEMPLATE.json',
      'animated-card.json',
      'blog-card.json',
      'minimal-blog-card.json',
      'minimal-card.json',
      'modern-product-card.json',
      'product-card.json',
      'testimonal.json'
    ];

    let loadedCount = 0;
    let errorCount = 0;

    styleFiles.forEach(filename => {
      fetch(`style/${filename}`)
        .then(response => {
          if (!response.ok) {
            throw new Error(`Failed to load ${filename}`);
          }
          return response.json();
        })
        .then(styleData => {
          const existingIndex = this.styleSets.findIndex(s => s.id === styleData.id);
          
          const styleSet = {
            id: styleData.id || Date.now() + Math.random(),
            name: styleData.name || filename.replace('.json', ''),
            description: styleData.description || '',
            cardBg: styleData.cardBg || styleData.cardStyle?.bg || '#ffffff',
            cardText: styleData.cardText || styleData.cardStyle?.text || '#1f2937',
            cardBorder: styleData.cardBorder || styleData.cardStyle?.border || '#e5e7eb',
            cardAccent: styleData.cardAccent || styleData.fields?.price?.color || '#7c2bee',
            cardRadius: styleData.cardRadius || styleData.cardStyle?.radius || 12,
            cardPadding: styleData.cardPadding || styleData.cardStyle?.padding || 16,
            cardShadow: styleData.cardShadow || styleData.cardStyle?.shadow || 'md',
            fields: styleData.fields || {},
            hover: styleData.hover || {},
            template: styleData.template || null,
            grid: styleData.grid || null,
            dataMapping: styleData.dataMapping || null,
            textStyles: styleData.textStyles || {},
            animation: styleData.animation || { enabled: false },
            isNewFormat: styleData.template && (styleData.template.html || styleData.template.css)
          };

          if (existingIndex >= 0) {
            this.styleSets[existingIndex] = styleSet;
          } else {
            this.styleSets.push(styleSet);
          }

          loadedCount++;
          console.log(`Loaded style set: ${styleSet.name}`);

          if (loadedCount + errorCount === styleFiles.length) {
            this.renderStyleSets();
            this.renderPreview();
            this.saveData();
            this.showToast(`Loaded ${loadedCount} style sets from style folder`, 'success');
          }
        })
        .catch(error => {
          console.error(`Error loading ${filename}:`, error);
          errorCount++;
        });
    });
  }

  applyStyleSet(id) {
    const styleSet = this.styleSets.find(s => s.id === id || String(s.id) === String(id));
    if (styleSet) {
      this.currentStyle = styleSet;

      if (styleSet.isNewFormat && styleSet.grid) {
        this.gridConfig = {
          columns: styleSet.grid.columns || 4,
          gap: styleSet.grid.gap || 24,
          minWidth: styleSet.grid.minWidth || 280,
          maxWidth: styleSet.grid.maxWidth || 1440
        };
      }

      document.getElementById('cardBg').value = styleSet.cardBg;
      document.getElementById('cardText').value = styleSet.cardText;
      document.getElementById('cardBorder').value = styleSet.cardBorder;
      document.getElementById('cardAccent').value = styleSet.cardAccent;
      document.getElementById('cardRadius').value = styleSet.cardRadius;
      document.getElementById('cardRadiusValue').textContent = styleSet.cardRadius;
      document.getElementById('cardPadding').value = styleSet.cardPadding;
      document.getElementById('cardPaddingValue').textContent = styleSet.cardPadding;
      document.getElementById('cardShadow').value = styleSet.cardShadow;

      if (this.selectedSection) {
        this.selectedSection.gridEnabled = true;
        this.selectedSection.gridColumns = this.gridConfig.columns;
        this.selectedSection.gridGap = this.gridConfig.gap;
        this.selectedSection.gridMinWidth = this.gridConfig.minWidth;
        this.selectedSection.gridMaxWidth = this.gridConfig.maxWidth;
        this.selectedSection.styleApplied = true;
        this.selectedSection.styleSetId = id;
      }

      this.renderStyleSets();
      this.renderSections();
      this.renderPreview();
      this.showToast('Style set applied: ' + styleSet.name, 'success');
    }
  }

  toggleStyleOnSection(id, apply) {
    if (!this.selectedSection) {
      this.showToast('Please select a section first', 'error');
      return;
    }
    
    if (apply) {
      this.applyStyleSet(id);
    } else {
      this.selectedSection.styleApplied = false;
      this.selectedSection.styleSetId = null;
      this.selectedSection.gridEnabled = false;
      this.renderStyleSets();
      this.renderSections();
      this.renderPreview();
      this.saveData();
      this.showToast('Style set removed', 'success');
    }
  }

  deleteStyleSet(id) {
    if (confirm('Are you sure you want to delete this style set?')) {
      this.styleSets = this.styleSets.filter(s => s.id !== id);
      if (this.currentStyle && this.currentStyle.id === id) {
        this.currentStyle = null;
      }
      this.renderStyleCategoryOptions();
      this.renderStyleSelect();
      this.renderStyleSets();
      this.renderPreview();
      this.saveData();
      this.showToast('Style set deleted', 'success');
    }
  }

  renderStyleSets() {
    const container = document.getElementById('styleSetList');
    const select = document.getElementById('styleSetSelect');
    
    const displayStyleSets = this.styleSets;
    
    if (displayStyleSets.length === 0) {
      container.innerHTML = '<p style="color: #6b7280; font-size: 14px;">No style set selected</p>';
      return;
    }

    container.innerHTML = displayStyleSets.map(styleSet => {
      const isAppliedToSelected = this.selectedSection && this.selectedSection.styleSetId === styleSet.id;
      
      let previewHtml = '';
      
      if (styleSet.template && styleSet.template.html) {
        const previewData = this.sheetData.length > 0 ? this.sheetData[0] : null;
        const dataMapping = styleSet.dataMapping || {};
        const fields = styleSet.fields || {};
        
        const fieldValues = {};
        const imageDefault = fields.image?.default || '';
        
        if (previewData) {
          console.log('=== Style Preview Data ===');
          console.log('Style:', styleSet.name);
          console.log('Preview data keys:', Object.keys(previewData));
          console.log('Data mapping:', dataMapping);
          console.log('Full preview data:', previewData);
        } else {
          console.log('=== Style Preview Data ===');
          console.log('Style:', styleSet.name);
          console.log('No preview data available (sheetData length:', this.sheetData.length, ')');
        }
        
        for (const [fieldName, possibleKeys] of Object.entries(dataMapping)) {
          let value = '';
          
          if (previewData) {
            for (const key of possibleKeys) {
              if (previewData[key] !== undefined && previewData[key] !== '') {
                value = previewData[key];
                console.log(`Found ${fieldName} from key "${key}":`, value);
                break;
              }
            }
          }
          
          if (!value) {
            const fieldConfig = fields[fieldName];
            value = fieldConfig?.default || '';
            console.log(`Using default for ${fieldName}:`, value);
          }
          
          fieldValues[fieldName] = value;
        }
        
        if (fieldValues['image'] && fieldValues['image'] !== imageDefault) {
          const originalImageUrl = fieldValues['image'];
          fieldValues['image'] = this.convertGoogleDriveUrl(fieldValues['image']);
          console.log('Image URL converted:', originalImageUrl, '->', fieldValues['image']);
        }
        
        let template = styleSet.template.html;
        for (const [field, value] of Object.entries(fieldValues)) {
          const regex = new RegExp(`{{${field}}}`, 'g');
          template = template.replace(regex, value);
        }
        
        template = template.replace(/<img\s+/g, '<img crossorigin="anonymous" ');
        template = template.replace(/<img([^>]*?)src="([^"]*?)"/g, (match, attrs, src) => {
          const convertedSrc = this.convertGoogleDriveUrl(src);
          return `<img${attrs}src="${convertedSrc}" onerror="this.onerror=null;this.src='${imageDefault}'"`;
        });
        
        const css = styleSet.template.css || '';
        const bg = styleSet.cardBg || styleSet.cardStyle?.bg || '#ffffff';
        const text = styleSet.cardText || styleSet.cardStyle?.text || '#1f2937';
        const border = styleSet.cardBorder || styleSet.cardStyle?.border || '#e5e7eb';
        const radius = styleSet.cardRadius || styleSet.cardStyle?.radius || 12;
        const padding = styleSet.cardPadding || styleSet.cardStyle?.padding || 16;
        const shadow = styleSet.cardShadow || styleSet.cardStyle?.shadow || 'md';
        
        const shadowValue = this.getShadowValue(shadow);
        
        let textStylesCSS = '';
        if (styleSet.textStyles) {
          const ts = styleSet.textStyles;
          if (ts.title) textStylesCSS += `--title-color: ${ts.title.color}; --title-font-size: ${ts.title.fontSize}px; --title-font-weight: ${ts.title.fontWeight}; --title-line-height: ${ts.title.lineHeight}; --title-letter-spacing: ${ts.title.letterSpacing}px; --title-text-align: ${ts.title.textAlign}; --title-text-transform: ${ts.title.textTransform};`;
          if (ts.subtitle) textStylesCSS += `--subtitle-color: ${ts.subtitle.color}; --subtitle-font-size: ${ts.subtitle.fontSize}px; --subtitle-font-weight: ${ts.subtitle.fontWeight}; --subtitle-line-height: ${ts.subtitle.lineHeight}; --subtitle-letter-spacing: ${ts.subtitle.letterSpacing}px; --subtitle-text-align: ${ts.subtitle.textAlign}; --subtitle-text-transform: ${ts.subtitle.textTransform};`;
          if (ts.description) textStylesCSS += `--description-color: ${ts.description.color}; --description-font-size: ${ts.description.fontSize}px; --description-font-weight: ${ts.description.fontWeight}; --description-line-height: ${ts.description.lineHeight}; --description-letter-spacing: ${ts.description.letterSpacing}px; --description-text-align: ${ts.description.textAlign}; --description-text-transform: ${ts.description.textTransform};`;
          if (ts.author) textStylesCSS += `--author-color: ${ts.author.color}; --author-font-size: ${ts.author.fontSize}px; --author-font-weight: ${ts.author.fontWeight}; --author-line-height: ${ts.author.lineHeight}; --author-letter-spacing: ${ts.author.letterSpacing}px; --author-text-align: ${ts.author.textAlign}; --author-text-transform: ${ts.author.textTransform};`;
          if (ts.role) textStylesCSS += `--role-color: ${ts.role.color}; --role-font-size: ${ts.role.fontSize}px; --role-font-weight: ${ts.role.fontWeight}; --role-line-height: ${ts.role.lineHeight}; --role-letter-spacing: ${ts.role.letterSpacing}px; --role-text-align: ${ts.role.textAlign}; --role-text-transform: ${ts.role.textTransform};`;
          if (ts.price) textStylesCSS += `--price-color: ${ts.price.color}; --price-font-size: ${ts.price.fontSize}px; --price-font-weight: ${ts.price.fontWeight}; --price-line-height: ${ts.price.lineHeight}; --price-letter-spacing: ${ts.price.letterSpacing}px; --price-text-align: ${ts.price.textAlign}; --price-text-transform: ${ts.price.textTransform};`;
        }
        
        previewHtml = `
          <div class="card-preview-wrapper" style="max-width: 300px;">
            <style>
              .card-preview-wrapper {
                --card-bg: ${bg};
                --card-text: ${text};
                --card-border: ${border};
                --card-radius: ${radius}px;
                --card-padding: ${padding}px;
                --card-shadow: ${shadowValue};
                ${textStylesCSS}
              }
              ${css}
            </style>
            ${template}
          </div>
        `;
      } else {
        const previewData = this.sheetData.length > 0 ? this.sheetData[0] : null;
        
        let previewImageUrl = 'https://via.placeholder.com/300x300/7c2bee/ffffff?text=Product';
        let previewNameText = 'Product Name';
        let previewPriceText = '$99';
        let previewDescText = 'This is a sample product description to demonstrate the style effect';
        
        if (previewData) {
          const imageKeys = ['image', 'url', 'cover', '图片', '图片链接', '封面', '封面图'];
          let previewImage = null;
          for (const key of imageKeys) {
            if (previewData[key]) {
              previewImage = key;
              break;
            }
          }
          
          if (previewImage && previewData[previewImage]) {
            previewImageUrl = previewData[previewImage];
          }
          
          const originalPreviewUrl = previewImageUrl;
          previewImageUrl = this.convertGoogleDriveUrl(previewImageUrl);
          
          const nameKeys = ['name', 'title', '商品名称', '名称', '标题'];
          for (const key of nameKeys) {
            if (previewData[key]) {
              previewNameText = previewData[key];
              break;
            }
          }
          
          const priceKeys = ['price', '价格', '售价'];
          for (const key of priceKeys) {
            if (previewData[key]) {
              previewPriceText = previewData[key];
              break;
            }
          }
          
          const descKeys = ['description', 'desc', '描述', '商品描述', 'summary', '摘要'];
          for (const key of descKeys) {
            if (previewData[key]) {
              previewDescText = previewData[key];
              break;
            }
          }
        }
        
        const convertedPreviewUrl = this.convertGoogleDriveUrl(previewImageUrl);
        const imageDefaultUrl = styleSet.fields?.image?.default || 'https://via.placeholder.com/300x300/7c2bee/ffffff?text=Image+Error';
        
        previewHtml = `
          <div class="mini-card" style="background: ${styleSet.cardBg}; color: ${styleSet.cardText}; border: 1px solid ${styleSet.cardBorder}; border-radius: ${styleSet.cardRadius}px; padding: ${styleSet.cardPadding}px;">
            <img src="${convertedPreviewUrl}" alt="${previewNameText}" onerror="this.onerror=null;this.src='${imageDefaultUrl}'" style="width: 100%; aspect-ratio: 1/1; object-fit: cover; border-radius: 8px; margin-bottom: 12px;">
            <div class="mini-card-title" style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">${previewNameText}</div>
            <div class="mini-card-accent" style="font-size: 18px; font-weight: 700; color: ${styleSet.cardAccent}; margin-bottom: 8px;">${previewPriceText}</div>
            <div class="mini-card-body" style="font-size: 13px; line-height: 1.5; color: #6b7280; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">${previewDescText}</div>
          </div>
        `;
      }
      
      return `
      <div class="style-set-item ${this.currentStyle && this.currentStyle.id === styleSet.id ? 'selected' : ''}">
        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
          <div class="style-set-name">${styleSet.name}</div>
          <label style="display: flex; align-items: center; gap: 6px; font-size: 12px; cursor: pointer;">
            <input type="checkbox" ${isAppliedToSelected ? 'checked' : ''} 
                   onchange="editor.toggleStyleOnSection('${styleSet.id}', this.checked)"
                   style="width: 16px; height: 16px; cursor: pointer;">
            Apply
          </label>
        </div>
        ${styleSet.description ? `<div class="style-set-description">${styleSet.description}</div>` : ''}
        <div class="style-set-preview">
          ${previewHtml}
        </div>
        <div style="margin-top: 8px; display: flex; gap: 8px;">
          <button class="btn btn-primary" onclick="editor.applyStyleSet('${styleSet.id}')">Apply</button>
          <button class="btn btn-secondary" onclick="editor.deleteStyleSet('${styleSet.id}')">Delete</button>
        </div>
      </div>
    `;
    }).join('');

    if (select) {
      select.innerHTML = `
        <option value="">Select style set...</option>
        ${this.styleSets.map(styleSet => `
          <option value="${styleSet.id}" ${this.currentStyle && this.currentStyle.id === styleSet.id ? 'selected' : ''}>
            ${styleSet.name}
          </option>
        `).join('')}
      `;
      select.addEventListener('change', (e) => {
        if (e.target.value) {
          this.applyStyleSet(parseFloat(e.target.value));
        }
      });
    }
  }

  setPreviewWidth(width) {
    this.previewWidth = width;
    this.updatePreviewContainer();
    this.renderPreview();
  }

  updatePreviewContainer() {
    const container = document.getElementById('previewContainer');
    const widths = {
      desktop: '100%',
      tablet: '768px',
      mobile: '375px'
    };
    container.style.maxWidth = widths[this.previewWidth];
    container.style.margin = '0 auto';
  }

  renderPreview() {
    const container = document.getElementById('previewContainer');
    
    console.log('=== renderPreview called ===');
    console.log('Sections count:', this.sections.length);
    console.log('Sections:', this.sections.map(s => ({ id: s.id, name: s.name, visible: s.visible, type: s.type, gridEnabled: s.gridEnabled })));
    console.log('Sheet data count:', this.sheetData.length);
    console.log('Current style:', this.currentStyle?.name);
    
    if (this.sections.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
          <h3>Start Your Project</h3>
          <p>Import HTML or add sections to begin editing</p>
        </div>
      `;
      return;
    }

    const htmlClass = [this.originalHtmlClass, this.previewTheme].filter(Boolean).join(' ').trim();
    let html = `<!DOCTYPE html><html${htmlClass ? ' class="' + htmlClass + '"' : ''} data-theme="${this.previewTheme}" dir="${this.previewDirection}"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">`;
    
    if (this.originalHead) {
      html += this.originalHead;
    }
    
    if (this.currentStyle || this.selectedSection?.gridEnabled) {
      html += '<style>';
      
      if (this.currentStyle || this.selectedSection?.gridEnabled) {
        html += `
          .grid-container {
            max-width: ${this.gridConfig.maxWidth}px;
            margin: 0 auto;
            width: 100%;
          }
        `;
      }
      
      if (this.currentStyle) {
        console.log('=== Generating Style CSS ===');
        console.log('Style name:', this.currentStyle.name);
        console.log('Is new format:', this.currentStyle.isNewFormat);
        console.log('Has template CSS:', !!this.currentStyle.template?.css);
        console.log('Has text styles:', !!this.currentStyle.textStyles);
        console.log('Text styles:', this.currentStyle.textStyles);

        const animEnabled = this.currentStyle.animation?.enabled ?? false;
        const animHover = this.currentStyle.animation?.hover || {};
        const animEntry = this.currentStyle.animation?.entry || {};

        if (this.currentStyle.isNewFormat && this.currentStyle.template?.css) {
          html += `
            .card {
              --card-bg: ${this.currentStyle.cardBg};
              --card-bg-dark: ${this.currentStyle.cardBgDark || this.currentStyle.cardBg};
              --card-text: ${this.currentStyle.cardText};
              --card-text-dark: ${this.currentStyle.cardTextDark || this.currentStyle.cardText};
              --card-border: ${this.currentStyle.cardBorder};
              --card-radius: ${this.currentStyle.cardRadius}px;
              --card-padding: ${this.currentStyle.cardPadding}px;
              --card-shadow: ${this.getShadowValue(this.currentStyle.cardShadow)};
            }
            [data-theme="dark"] .card {
              --card-bg: ${this.currentStyle.cardBgDark || this.currentStyle.cardBg};
              --card-text: ${this.currentStyle.cardTextDark || this.currentStyle.cardText};
            }
            ${this.generateTextStylesCSS(this.currentStyle.textStyles || {})}
            ${this.generateAnimationCSS(animEnabled, animHover, animEntry)}
            ${this.currentStyle.template.css}
          `;
        } else {
          html += `
            .card {
              background: ${this.currentStyle.cardBg};
              color: ${this.currentStyle.cardText};
              border: 1px solid ${this.currentStyle.cardBorder};
              border-radius: ${this.currentStyle.cardRadius}px;
              padding: ${this.currentStyle.cardPadding}px;
              box-shadow: ${this.getShadowValue(this.currentStyle.cardShadow)};
              display: flex;
              flex-direction: column;
              ${animEnabled ? 'transition: transform 0.2s ease, box-shadow 0.2s ease;' : ''}
            }
            ${animEnabled && animHover.cardLift ? `
            .card:hover {
              transform: translateY(-${animHover.liftDistance || 4}px);
              ${animHover.cardShadow ? `box-shadow: 0 12px 24px rgba(0,0,0,${animHover.shadowIntensity || 0.15});` : ''}
            }
            ` : ''}
            .card img {
              ${animEnabled && animHover.imageZoom ? 'transition: transform 0.2s ease;' : ''}
            }
            ${animEnabled && animHover.imageZoom ? `
            .card:hover img {
              transform: scale(${animHover.imageScale || 1.05});
            }
            ` : ''}
            ${this.generateTextStylesCSS(this.currentStyle.textStyles || {})}
            ${this.generateAnimationCSS(animEnabled, animHover, animEntry)}
          `;
        }

        html += `
          @media (max-width: 599px) {
            .grid-container {
              grid-template-columns: repeat(2, 1fr) !important;
              gap: 12px !important;
            }
          }
          @media (min-width: 600px) and (max-width: 1023px) {
            .grid-container {
              grid-template-columns: repeat(3, 1fr) !important;
              gap: 16px !important;
            }
          }
          @media (min-width: 1024px) {
            .grid-container {
              grid-template-columns: repeat(${this.gridConfig.columns}, 1fr) !important;
              gap: ${this.gridConfig.gap}px !important;
            }
          }
        `;

        if (!this.currentStyle.isNewFormat || !this.currentStyle.template?.css) {
          html += `
            .card h3 {
              margin: 0 0 8px 0;
              font-size: 16px;
              font-weight: 600;
            }

            .card .subtitle {
              margin: 0 0 4px 0;
              font-size: 12px;
              font-weight: 500;
              color: #6b7280;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }

            .card .price {
              margin: 0 0 8px 0;
              font-size: 18px;
              font-weight: 700;
              color: var(--primary, #7c2bee);
            }

            .card p {
              margin: 0;
              font-size: 13px;
              line-height: 1.5;
              color: #6b7280;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
            }

            .card .badge {
              background: ${this.currentStyle?.cardAccent || '#7c2bee'};
              color: white;
              padding: 4px 8px;
              border-radius: 4px;
              font-size: 12px;
            }
          `;
        }
      }

      const hasGridSections = this.sections.some(s => s.visible && s.gridEnabled);
      if (hasGridSections) {
        // Generate responsive grid CSS based on config
        const desktopCols = this.gridConfig.columnsDesktop || 4;
        const tabletCols = this.gridConfig.columnsTablet || 2;
        const phoneCols = this.gridConfig.columnsPhone || 1;
        const gap = this.gridConfig.gap || 24;
        const maxWidth = this.gridConfig.maxWidth || 1440;
        
        html += `
          /* Responsive Grid System */
          .grid-container {
            display: grid;
            gap: ${gap}px;
            max-width: ${maxWidth}px;
            width: 100%;
            margin: 0 auto;
          }
          
          /* Phone (default) */
          .grid-container {
            grid-template-columns: repeat(${phoneCols}, 1fr);
          }
          
          /* Tablet */
          @media (min-width: 768px) {
            .grid-container {
              grid-template-columns: repeat(${tabletCols}, 1fr);
            }
          }
          
          /* Desktop */
          @media (min-width: 1024px) {
            .grid-container {
              grid-template-columns: repeat(${desktopCols}, 1fr);
            }
          }
          
          /* Card placeholder styles */
          .placeholder-card {
            background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
            border: 2px dashed #d1d5db;
            border-radius: 12px;
            min-height: 280px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
            cursor: pointer;
          }
          
          .placeholder-card:hover {
            background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
            border-color: #9ca3af;
            transform: translateY(-2px);
          }
          
          .placeholder-card svg {
            width: 48px;
            height: 48px;
            margin-bottom: 12px;
            opacity: 0.5;
          }
        `;
      }

      html += '</style>';
    }
    
    html += '<script>';
    html += `
      console.log('=== Preview Debug Info ===');
      console.log('Grid Config:', ${JSON.stringify(this.gridConfig)});
      console.log('Current Style:', ${JSON.stringify(this.currentStyle)});
      console.log('Sheet Data Count:', ${this.sheetData.length});
      console.log('Sections Count:', ${this.sections.length});
      
      document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM loaded in preview iframe');
        const images = document.querySelectorAll('img');
        console.log('Images found:', images.length);
        images.forEach((img, index) => {
          console.log('Image', index, '- src:', img.src);
          img.addEventListener('load', function() {
            console.log('Image', index, 'loaded successfully:', this.src);
          });
          img.addEventListener('error', function() {
            console.error('Image', index, 'failed to load:', this.src);
          });
        });
      });
    `;
    html += '</script>';
    
    // Add Tally SDK script if any Tally sections exist
    if (this.sections.some(s => s.type === 'tally')) {
      html += '<script src="https://tally.so/widgets/embed.js"></script>';
    }
    
    html += '</head><body class="preview-body">';

    console.log('=== Rendering Preview Sections ===');
    console.log('Total sections:', this.sections.length);
    console.log('Visible sections:', this.sections.filter(s => s.visible).length);

    this.sections.forEach(section => {
      if (section.visible) {
        console.log('Rendering section:', section.name, 'type:', section.type);
        
        if (section.type === 'tally') {
          console.log('=== Rendering Tally Section ===');
          console.log('Section name:', section.name);
          console.log('Section URL:', section.url);
          console.log('Section embedHtml:', section.embedHtml ? 'YES (length: ' + section.embedHtml.length + ')' : 'NO');
          console.log('Full section data:', section);
          
          const config = section.config || {};
          const width = config.width || 1200;
          const padding = config.padding || { top: 60, bottom: 60, left: 20, right: 20 };
          
          // support either embed HTML (section.embedHtml) or direct embed url (section.url)
          if (section.embedHtml) {
            console.log('=== Rendering embed HTML ===');
            // Ensure the embed HTML includes Tally SDK attributes if it's an iframe
            let embedContent = section.embedHtml;
            if (embedContent.includes('<iframe') && !embedContent.includes('data-tally')) {
              // If it's an iframe but not marked as Tally embed, add data-tally attribute
              embedContent = embedContent.replace('<iframe', '<iframe data-tally-embed="true"');
            }
            
            html += `<div class="tally-section" style="
              max-width: ${width}px;
              margin: 0 auto;
              padding: ${padding.top}px ${padding.right}px ${padding.bottom}px ${padding.left}px;
              position: relative;
              border: 2px dashed #10b981;
              background: rgba(16, 185, 129, 0.02);
              border-radius: 4px;
            ">`;
            html += `<div class="section-label" style="
              position: absolute;
              top: -10px;
              left: 12px;
              background: #10b981;
              color: white;
              padding: 2px 8px;
              font-size: 12px;
              border-radius: 2px;
              font-weight: 500;
              z-index: 10;
            ">${section.name}</div>`;
            html += embedContent;
            html += `</div>`;
          } else {
            const embedUrl = section.url || '';
            console.log('Using iframe mode with URL:', embedUrl);
            
            if (!embedUrl) {
              console.error('Tally section has no URL or embedHtml!');
              html += `<div class="tally-section" style="
                max-width: ${width}px;
                margin: 0 auto;
                padding: ${padding.top}px ${padding.right}px ${padding.bottom}px ${padding.left}px;
                position: relative;
                border: 2px dashed #ef4444;
                background: rgba(239, 68, 68, 0.02);
                border-radius: 4px;
              ">`;
              html += `<div class="section-label" style="
                position: absolute;
                top: -10px;
                left: 12px;
                background: #ef4444;
                color: white;
                padding: 2px 8px;
                font-size: 12px;
                border-radius: 2px;
                font-weight: 500;
              ">${section.name} - ERROR</div>`;
              html += `<p style="padding: 20px; color: #ef4444;">No Tally URL or embed code provided. Please edit this section and add a Tally link or embed code.</p>`;
              html += `</div>`;
              return;
            }
            
            const formId = embedUrl.match(/\/embed\/([a-zA-Z0-9]+)/)?.[1] || '';

            html += `<div class="tally-section" style="
              max-width: ${width}px;
              margin: 0 auto;
              padding: ${padding.top}px ${padding.right}px ${padding.bottom}px ${padding.left}px;
              position: relative;
              border: 2px dashed #10b981;
              background: rgba(16, 185, 129, 0.02);
              border-radius: 4px;
            ">`;
            html += `<div class="section-label" style="
              position: absolute;
              top: -10px;
              left: 12px;
              background: #10b981;
              color: white;
              padding: 2px 8px;
              font-size: 12px;
              border-radius: 2px;
              font-weight: 500;
            ">${section.name}</div>`;
            html += `<iframe 
              src="${embedUrl}" 
              data-tally-embed="${formId}"
              data-tally-width="100%"
              data-tally-auto-height="true"
              title="${section.name}" 
              style="width: 100%; height: 600px; border: none; background: transparent;"
              frameborder="0"
              marginheight="0"
              marginwidth="0"
              loading="lazy"
            ></iframe>`;
            html += `</div>`;
          }
        } else if (section.gridEnabled) {
          const sectionStyle = section.styleSetId
            ? this.styleSets.find(s => s.id === section.styleSetId)
            : this.currentStyle;
          const sectionGridColumns = section.gridColumnsDesktop || section.gridColumns || this.gridConfig.columnsDesktop || 4;
          const sectionGridGap = section.gridGap || this.gridConfig.gap || 24;
          const sectionGridMaxWidth = section.gridMaxWidth || this.gridConfig.maxWidth || 1440;
          const sectionPadding = section.gridSectionPadding || this.gridConfig.sectionPadding || 40;
          const sectionCardLimit = section.gridCardLimit ?? this.gridConfig.cardLimit ?? 0;
          const sectionMinHeight = section.sectionMinHeight || sectionStyle?.layout?.minHeight || 0;
          const sectionFullWidth = section.sectionFullWidth || sectionStyle?.layout?.fullWidth || false;
          const cardWidthMode = section.cardWidthMode || sectionStyle?.layout?.width || 'auto';
          const cardCustomWidth = section.cardCustomWidth || sectionStyle?.layout?.customWidth || 0;
          const showPlaceholders = section.showPlaceholders !== false;

          console.log('=== Rendering Grid Section ===');
          console.log('Section ID:', section.id);
          console.log('Section name:', section.name);
          console.log('Grid columns:', sectionGridColumns);
          console.log('Grid gap:', sectionGridGap);
          console.log('Grid max width:', sectionGridMaxWidth);
          console.log('Section padding:', sectionPadding);
          console.log('Card limit:', sectionCardLimit);
          console.log('Show placeholders:', showPlaceholders);
          console.log('Sheet data count:', this.sheetData.length);
          console.log('Current style:', this.currentStyle?.name);

          if (sectionStyle?.layout?.type === 'section') {
            const previousStyle = this.currentStyle;
            this.currentStyle = sectionStyle;
            const sectionData = this.sheetData[0] || {};
            const renderedSection = this.renderCard(sectionData);
            this.currentStyle = previousStyle;

            html += `<div class="section-framework" style="
              position: relative;
              border: 2px dashed #3b82f6;
              padding: ${sectionFullWidth ? 0 : sectionPadding}px;
              margin: 8px 0;
              background: rgba(59, 130, 246, 0.02);
              border-radius: 4px;
              min-height: ${sectionMinHeight}px;
            ">`;
            html += `<div class="section-label" style="
              position: absolute;
              top: -10px;
              left: 12px;
              background: #3b82f6;
              color: white;
              padding: 2px 8px;
              font-size: 12px;
              border-radius: 2px;
              font-weight: 500;
              z-index: 2;
            ">${section.name} · ${sectionStyle.name}</div>`;
            html += renderedSection;
            html += `</div>`;
            return;
          }

          html += `<div class="section-framework" style="
            position: relative;
            border: 2px dashed #3b82f6;
            padding: ${sectionPadding}px;
            margin: 8px 0;
            background: rgba(59, 130, 246, 0.02);
            border-radius: 4px;
            min-height: ${sectionMinHeight}px;
          ">`;
          html += `<div class="section-label" style="
            position: absolute;
            top: -10px;
            left: 12px;
            background: #3b82f6;
            color: white;
            padding: 2px 8px;
            font-size: 12px;
            border-radius: 2px;
            font-weight: 500;
          ">${section.name} (${this.sheetData.length} items loaded)</div>`;
          
          html += `<div class="grid-container" style="
            display: grid;
            grid-template-columns: repeat(${sectionGridColumns}, 1fr);
            gap: ${sectionGridGap}px;
            max-width: ${sectionGridMaxWidth}px;
            margin: 0 auto;
          ">`;

          if (this.sheetData.length > 0) {
            console.log('Rendering data cards...');
            const dataToRender = sectionCardLimit > 0 ? this.sheetData.slice(0, sectionCardLimit) : this.sheetData;
            console.log('Card limit applied:', sectionCardLimit);
            console.log('Cards to render:', dataToRender.length);
            
            let cardCount = 0;
            dataToRender.forEach((item, index) => {
              if (index < 10) {
                console.log(`Card ${index + 1} data:`, item);
              }
              const cardStyle = [
                'cursor: pointer;'
              ];
              if (cardWidthMode === 'custom' && cardCustomWidth > 0) {
                cardStyle.push(`max-width: ${cardCustomWidth}px; width: 100%; justify-self: center;`);
              }
              if (cardWidthMode === 'full') {
                cardStyle.push('grid-column: 1 / -1; width: 100%;');
              }
              if (sectionMinHeight > 0) {
                cardStyle.push(`min-height: ${sectionMinHeight}px;`);
              }
              html += `<div class="card" data-card-index="${index}" onclick="window.parent.postMessage({type:'cardClick', index:${index}, data:${JSON.stringify(item).replace(/"/g, '&quot;')}}, '*')" style="${cardStyle.join(' ')}">${this.renderCard(item)}</div>`;
              cardCount++;
            });
            console.log('Total cards rendered:', cardCount);
            
            // Add placeholders if enabled
            if (showPlaceholders && dataToRender.length < sectionGridColumns) {
              const placeholdersNeeded = sectionGridColumns - (dataToRender.length % sectionGridColumns);
              if (placeholdersNeeded < sectionGridColumns) {
                for (let i = 0; i < placeholdersNeeded; i++) {
                  html += `<div class="placeholder-card">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                      <rect x="3" y="3" width="18" height="18" rx="2"/>
                      <path d="M3 9h18M9 21V9"/>
                    </svg>
                    <div>Empty Slot</div>
                  </div>`;
                }
              }
            }
          } else if (showPlaceholders) {
            // Show placeholders when no data
            const totalPlaceholders = sectionGridColumns * 2; // Show 2 rows by default
            for (let i = 0; i < totalPlaceholders; i++) {
              html += `<div class="placeholder-card">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <rect x="3" y="3" width="18" height="18" rx="2"/>
                  <path d="M3 9h18M9 21V9"/>
                </svg>
                <div>Card ${i + 1}</div>
                <div style="font-size: 11px; opacity: 0.7; margin-top: 4px;">Load data from Google Sheets</div>
              </div>`;
            }
          }
          html += `</div>`;
          html += `</div>`;
        } else {
          html += `<div class="section-framework" style="
            position: relative;
            border: 2px dashed #7c2bee;
            padding: 8px;
            margin: 8px 0;
            background: rgba(124, 43, 238, 0.02);
            border-radius: 4px;
          ">`;
          html += `<div class="section-label" style="
            position: absolute;
            top: -10px;
            left: 12px;
            background: #7c2bee;
            color: white;
            padding: 2px 8px;
            font-size: 12px;
            border-radius: 2px;
            font-weight: 500;
          ">${section.name}</div>`;
          html += section.content;
          html += `</div>`;
        }
      }
    });

    html += '</body></html>';

    console.log('Creating preview iframe with blob URL');
    const blob = new Blob([html], { type: 'text/html' });
    const blobUrl = URL.createObjectURL(blob);
    // Add allow-same-origin to permit loading Tally SDK and other external resources
    container.innerHTML = `<iframe class="preview-iframe" src="${blobUrl}" sandbox="allow-scripts allow-same-origin allow-popups allow-forms allow-top-navigation allow-presentation allow-downloads allow-modals allow-popups-to-escape-sandbox allow-pointer-lock"></iframe>`;
    const iframe = container.querySelector('iframe');
    console.log('Preview iframe created with blob URL:', blobUrl);
  }

  convertGoogleDriveUrl(url) {
    if (!url) return '';
    
    console.log('convertGoogleDriveUrl called with:', url);
    
    const trimmedUrl = url.trim();
    
    if (trimmedUrl.includes('drive.google.com/file/d/')) {
      const idMatch = trimmedUrl.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) {
        const fileID = idMatch[1];
        const convertedUrl = `https://lh3.googleusercontent.com/d/${fileID}=w1600`;
        console.log('Converted URL (drive.google.com/file/d/):', trimmedUrl, '->', convertedUrl);
        return convertedUrl;
      }
    }
    
    if (trimmedUrl.includes('drive.google.com/open?id=')) {
      const idMatch = trimmedUrl.match(/drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) {
        const fileID = idMatch[1];
        const convertedUrl = `https://lh3.googleusercontent.com/d/${fileID}=w1600`;
        console.log('Converted URL (drive.google.com/open):', trimmedUrl, '->', convertedUrl);
        return convertedUrl;
      }
    }
    
    if (trimmedUrl.includes('docs.google.com/uc?id=')) {
      const idMatch = trimmedUrl.match(/docs\.google\.com\/uc\?id=([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) {
        const fileID = idMatch[1];
        const convertedUrl = `https://lh3.googleusercontent.com/d/${fileID}=w1600`;
        console.log('Converted URL (docs.google.com/uc):', trimmedUrl, '->', convertedUrl);
        return convertedUrl;
      }
    }
    
    if (trimmedUrl.includes('drive.google.com/thumbnail?id=')) {
      const idMatch = trimmedUrl.match(/drive\.google\.com\/thumbnail\?id=([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) {
        const fileID = idMatch[1];
        const convertedUrl = `https://lh3.googleusercontent.com/d/${fileID}=w1600`;
        console.log('Converted URL (drive.google.com/thumbnail):', trimmedUrl, '->', convertedUrl);
        return convertedUrl;
      }
    }
    
    if (trimmedUrl.includes('drive.google.com/uc?id=')) {
      const idMatch = trimmedUrl.match(/drive\.google\.com\/uc\?id=([a-zA-Z0-9_-]+)/);
      if (idMatch && idMatch[1]) {
        const fileID = idMatch[1];
        const convertedUrl = `https://lh3.googleusercontent.com/d/${fileID}=w1600`;
        console.log('Converted URL (drive.google.com/uc):', trimmedUrl, '->', convertedUrl);
        return convertedUrl;
      }
    }
    
    console.log('URL not converted, returning original:', trimmedUrl);
    return trimmedUrl;
  }

  findImageUrl(item) {
    if (!item) return '';
    
    console.log('findImageUrl called with item:', item);
    
    const keys = Object.keys(item);
    console.log('Available keys:', keys);
    
    const imagePatterns = ['image', 'url', 'avatar', 'portrait', 'photo', 'picture', 'pic', 'img', '图片', '照片', '头像', '缩略图', 'thumbnail', 'cover'];
    const imageKey = keys.find(k => imagePatterns.some(p => k.toLowerCase().includes(p)));
    
    console.log('Found image key:', imageKey);
    
    if (imageKey && item[imageKey]) {
      const url = this.convertGoogleDriveUrl(item[imageKey]);
      console.log('Converted image URL:', url);
      return url;
    }
    
    console.log('No image URL found in item');
    return '';
  }

  renderCard(item) {
    if (this.currentStyle?.isNewFormat && this.currentStyle?.template?.html) {
      return this.renderCardFromTemplate(item);
    }

    const overrides = this.currentStyle?.contentOverrides || {};
    const keys = Object.keys(item);
    const nameKey = keys.find(k => k.toLowerCase().includes('name')) || keys[0];
    const descKey = keys.find(k => k.toLowerCase().includes('desc') || k.toLowerCase().includes('description'));
    const priceKey = keys.find(k => k.toLowerCase().includes('price'));
    const imageKey = keys.find(k => k.toLowerCase().includes('image') || k.toLowerCase().includes('url'));
    const tagsKey = keys.find(k => k.toLowerCase().includes('tag'));
    const subtitleKey = keys.find(k => k.toLowerCase().includes('subtitle') || k.toLowerCase().includes('category'));

    const useTextStyles = this.currentStyle?.textStyles && Object.keys(this.currentStyle.textStyles).length > 0;

    let html = '';

    if (imageKey && (item[imageKey] || overrides.image)) {
      const originalUrl = overrides.image || item[imageKey];
      const imageUrl = this.convertGoogleDriveUrl(originalUrl);
      html += `<img src="${imageUrl}" alt="${item[nameKey] || ''}" onerror="this.onerror=null;this.src='https://via.placeholder.com/300x300/7c2bee/ffffff?text=Image+Error';console.error('Image failed to load:', '${originalUrl}');" style="width: 100%; aspect-ratio: 1/1; object-fit: cover; border-radius: 8px; margin-bottom: 12px;">`;
    }

    if (overrides.subtitle || (subtitleKey && item[subtitleKey])) {
      html += `<div class="subtitle">${overrides.subtitle || item[subtitleKey]}</div>`;
    }

    if (overrides.name || (nameKey && item[nameKey])) {
      html += `<h3>${overrides.name || item[nameKey]}</h3>`;
    }

    if (overrides.price || (priceKey && item[priceKey])) {
      html += `<div class="price">${overrides.price || item[priceKey]}</div>`;
    }

    if (overrides.description || (descKey && item[descKey])) {
      html += `<p>${overrides.description || item[descKey]}</p>`;
    }

    if (tagsKey && item[tagsKey]) {
      const tags = item[tagsKey].split(',').map(t => t.trim());
      html += `<div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px;">`;
      tags.forEach(tag => {
        html += `<span class="badge">${tag}</span>`;
      });
      html += `</div>`;
    }

    return html;
  }

  renderCardFromTemplate(item) {
    let template = this.currentStyle.template.html;
    const dataMapping = this.currentStyle.dataMapping || {};
    const overrides = this.currentStyle.contentOverrides || {};

    console.log('=== renderCardFromTemplate Debug ===');
    console.log('Input item:', item);
    console.log('Data mapping:', dataMapping);

    for (const [field, possibleKeys] of Object.entries(dataMapping)) {
      let value = overrides[field] || '';
      let foundKey = '';

      if (!value) {
        for (const key of possibleKeys) {
          if (item[key] !== undefined && item[key] !== null && item[key] !== '') {
            value = item[key];
            foundKey = key;
            break;
          }
        }
      }

      console.log(`Field "${field}":`);
      console.log('  Possible keys:', possibleKeys);
      console.log('  Found key:', foundKey);
      console.log('  Value:', value);

      if (!value) {
        const fieldConfig = this.currentStyle.fields?.[field];
        value = fieldConfig?.default || '';
        console.log('  Using default value:', value);
      }

      if (field === 'image' && value) {
        const originalUrl = value;
        value = this.convertGoogleDriveUrl(value);
        console.log('  Image conversion:');
        console.log('    Original:', originalUrl);
        console.log('    Converted:', value);
      }

      const regex = new RegExp(`{{${field}}}`, 'g');
      template = template.replace(regex, value);
    }

    console.log('Final template length:', template.length);
    template = template.replace(/<img\s+/g, '<img crossorigin="anonymous" ');
    template = template.replace(/{{[^}]+}}/g, '');

    return template;
  }

  getShadowValue(shadow) {
    const shadows = {
      none: 'none',
      sm: '0 1px 2px rgba(0, 0, 0, 0.05)',
      md: '0 4px 6px rgba(0, 0, 0, 0.1)',
      lg: '0 10px 15px rgba(0, 0, 0, 0.1)',
      xl: '0 20px 25px rgba(0, 0, 0, 0.15)'
    };
    if (typeof shadow === 'string' && (shadow.includes('rgba') || shadow.includes('rgb') || shadow.includes('px'))) {
      return shadow;
    }
    return shadows[shadow] || shadows.md;
  }

  generateTextStylesCSS(textStyles) {
    if (!textStyles || Object.keys(textStyles).length === 0) return '';

    let css = '';

    const styleSelectors = {
      title: '.card h3',
      subtitle: '.card .subtitle',
      description: '.card p',
      price: '.card .price',
      badge: '.card .badge',
      button: '.card button',
      author: '.card .author-name',
      role: '.card .author-role',
      testimonialText: '.card .testimonial-text'
    };

    for (const [styleType, selector] of Object.entries(styleSelectors)) {
      const style = textStyles[styleType];
      if (!style) continue;

      css += `\n${selector} {`;
      if (style.fontSize) css += `font-size: ${style.fontSize}px;`;
      if (style.fontWeight) css += `font-weight: ${style.fontWeight};`;
      if (style.color) css += `color: ${style.color};`;
      if (style.lineHeight) css += `line-height: ${style.lineHeight};`;
      if (style.letterSpacing !== undefined) css += `letter-spacing: ${style.letterSpacing}px;`;
      if (style.textAlign) css += `text-align: ${style.textAlign};`;
      if (style.textTransform) css += `text-transform: ${style.textTransform};`;
      css += '}';
    }

    return css;
  }

  generateAnimationCSS(enabled, hover, entry) {
    if (!enabled) return '';

    let css = '';

    if (entry.enabled && entry.type) {
      const duration = entry.duration || 0.4;
      const delay = entry.stagger ? 0.1 : 0;
      
      const keyframes = {
        fade: 'opacity: 0; opacity: 1;',
        slideUp: 'transform: translateY(20px); opacity: 0; transform: translateY(0); opacity: 1;',
        slideDown: 'transform: translateY(-20px); opacity: 0; transform: translateY(0); opacity: 1;',
        slideLeft: 'transform: translateX(20px); opacity: 0; transform: translateX(0); opacity: 1;',
        slideRight: 'transform: translateX(-20px); opacity: 0; transform: translateX(0); opacity: 1;',
        scale: 'transform: scale(0.9); opacity: 0; transform: scale(1); opacity: 1;'
      };

      if (keyframes[entry.type]) {
        css += `
          @keyframes cardEntry {
            from { ${keyframes[entry.type].split(';')[0]} }
            to { ${keyframes[entry.type].split(';').slice(1).join(';')} }
          }
          .card {
            animation: cardEntry ${duration}s ease-out ${delay}s backwards;
          }
        `;
      }
    }

    return css;
  }

  refreshPreview() {
    this.renderPreview();
    this.showToast('Preview refreshed', 'success');
  }

  exportHtml() {
    const html = this.generateHtml();
    this.downloadFile(html, 'aura-canvas.html', 'text/html');
    this.showToast('HTML exported', 'success');
  }

  exportProject() {
    const project = {
      sections: this.sections,
      sheetData: this.sheetData,
      styleSets: this.styleSets,
      currentStyle: this.currentStyle,
      gridConfig: this.gridConfig
    };
    const json = JSON.stringify(project, null, 2);
    this.downloadFile(json, 'aura-canvas-project.json', 'application/json');
    this.showToast('Project exported', 'success');
  }

  generateHtml() {
    let html = `<!DOCTYPE html>
<html${this.originalHtmlClass ? ' class="' + this.originalHtmlClass + '"' : ''}>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aura Canvas Export</title>
`;

    if (this.originalHead) {
      html += this.originalHead;
    }

    if (this.currentStyle) {
      html += `<style>
        .grid-container {
          max-width: ${this.gridConfig.maxWidth}px;
          margin: 0 auto;
          width: 100%;
        }
        .card {
          background: ${this.currentStyle.cardBg};
          color: ${this.currentStyle.cardText};
          border: 1px solid ${this.currentStyle.cardBorder};
          border-radius: ${this.currentStyle.cardRadius}px;
          padding: ${this.currentStyle.cardPadding}px;
          box-shadow: ${this.getShadowValue(this.currentStyle.cardShadow)};
          display: flex;
          flex-direction: column;
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 24px rgba(0,0,0,0.15);
        }
        .card img {
          transition: transform 0.2s ease;
        }
        .card:hover img {
          transform: scale(1.05);
        }
        .section-framework {
          position: relative;
          border: 2px dashed #7c2bee;
          padding: 8px;
          margin: 8px 0;
          background: rgba(124, 43, 238, 0.02);
          border-radius: 4px;
        }
        .section-label {
          position: absolute;
          top: -10px;
          left: 12px;
          background: #7c2bee;
          color: white;
          padding: 2px 8px;
          font-size: 12px;
          border-radius: 2px;
          font-weight: 500;
        }
        .tally-section {
          position: relative;
          border: 2px dashed #10b981;
          background: rgba(16, 185, 129, 0.02);
          border-radius: 4px;
        }
        .tally-section .section-label {
          background: #10b981;
        }
        .tally-section iframe {
          width: 100%;
          border: none;
        }
      </style>`;
    }

    const hasGridSections = this.sections.some(s => s.visible && s.gridEnabled);
    if (hasGridSections) {
      // Generate responsive grid CSS based on config
      const desktopCols = this.gridConfig.columnsDesktop || 4;
      const tabletCols = this.gridConfig.columnsTablet || 2;
      const phoneCols = this.gridConfig.columnsPhone || 1;
      const gap = this.gridConfig.gap || 24;
      const maxWidth = this.gridConfig.maxWidth || 1440;
      
      html += `<style>
        /* Responsive Grid System - Export */
        .grid-container {
          display: grid;
          gap: ${gap}px;
          max-width: ${maxWidth}px;
          width: 100%;
          margin: 0 auto;
          padding: 40px 20px;
        }
        
        /* Phone (default) */
        .grid-container {
          grid-template-columns: repeat(${phoneCols}, 1fr);
        }
        
        /* Tablet */
        @media (min-width: 768px) {
          .grid-container {
            grid-template-columns: repeat(${tabletCols}, 1fr);
          }
        }
        
        /* Desktop */
        @media (min-width: 1024px) {
          .grid-container {
            grid-template-columns: repeat(${desktopCols}, 1fr);
          }
        }
      </style>`;
    }

    html += `</head>
<body>
`;

    // Add Tally SDK if needed
    if (this.sections.some(s => s.type === 'tally')) {
      html += '<script src="https://tally.so/widgets/embed.js"><\/script>';
    }

    this.sections.forEach(section => {
      if (section.visible) {
        if (section.type === 'tally') {
          const config = section.config || {};
          const width = config.width || 1200;
          const padding = config.padding || { top: 60, bottom: 60, left: 20, right: 20 };
          html += `<div class="tally-section" style="
            max-width: ${width}px;
            margin: 0 auto;
            padding: ${padding.top}px ${padding.right}px ${padding.bottom}px ${padding.left}px;
          ">`;
          if (section.embedHtml) {
            html += section.embedHtml;
          } else {
            const embedUrl = section.url || '';
            const formId = embedUrl.match(/\/embed\/([a-zA-Z0-9]+)/)?.[1] || '';
            html += `<iframe 
              src="${embedUrl}" 
              data-tally-embed="${formId}"
              data-tally-width="100%"
              data-tally-auto-height="true"
              title="${section.name}" 
              style="width: 100%; height: 600px; border: none; background: transparent;"
              frameborder="0"
              marginheight="0"
              marginwidth="0"
              loading="lazy"
            ></iframe>`;
          }
          html += `</div>`;
        } else if (section.gridEnabled) {
          html += `<div class="grid-container">`;
          if (this.sheetData.length > 0) {
            const cardLimit = section.gridCardLimit || this.gridConfig.cardLimit || 0;
            const dataToRender = cardLimit > 0 ? this.sheetData.slice(0, cardLimit) : this.sheetData;
            dataToRender.forEach(item => {
              html += `<div class="card">${this.renderCard(item)}</div>`;
            });
          }
          html += `</div>`;
        } else {
          html += section.content;
        }
      }
    });

    html += `</body>
</html>`;

    return html;
  }

  downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  saveData() {
    const data = {
      sections: this.sections,
      styleSets: this.styleSets,
      currentStyleId: this.currentStyle?.id,
      gridConfig: this.gridConfig,
      previewTheme: this.previewTheme,
      previewDirection: this.previewDirection,
      originalHead: this.originalHead,
      originalHtmlClass: this.originalHtmlClass
    };
    localStorage.setItem('auraCanvasData', JSON.stringify(data));
  }

  loadSavedData() {
    const saved = localStorage.getItem('auraCanvasData');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        this.sections = data.sections || [];
        this.styleSets = data.styleSets || [];
        this.currentStyle = this.styleSets.find(s => s.id === data.currentStyleId) || null;
        this.gridConfig = data.gridConfig || this.gridConfig;
        this.previewTheme = data.previewTheme || 'light';
        this.previewDirection = data.previewDirection || 'ltr';
        this.originalHead = data.originalHead || '';
        this.originalHtmlClass = data.originalHtmlClass || '';
        
        // Remove duplicate Tally sections (keep only the last one of each type)
        const tallyCount = this.sections.filter(s => s.type === 'tally').length;
        if (tallyCount > 1) {
          console.log('Found', tallyCount, 'Tally sections, removing duplicates...');
          const lastTallyIndex = this.sections.length - 1 - [...this.sections].reverse().findIndex(s => s.type === 'tally');
          this.sections = this.sections.filter((s, idx) => s.type !== 'tally' || idx === lastTallyIndex);
          console.log('Kept only the last Tally section');
        }
        
        // Sanitize Tally URLs - fix any corrupted ones
        this.sections = this.sections.map(s => {
          if (s.type === 'tally' && s.url) {
            // Check if URL has corrupted parameters (doubled, mangled, etc.)
            if (s.url.includes('igenLeft') || s.url.includes('icHeight') || s.url.includes('2a1')) {
              console.warn('Detected corrupted Tally URL:', s.url);
              s.url = null; // Clear the corrupted URL, user will need to re-enter it
              console.log('Cleared corrupted URL');
            }
          }
          return s;
        });
        
        this.renderSections();
        this.renderStyleSets();
        this.updateStylePanelFromCurrentStyle(this.currentStyle);
      } catch (error) {
        console.error('Failed to load saved data:', error);
      }
    }
  }

  extractSpreadsheetId(url) {
    if (!url || typeof url !== 'string') {
      return null;
    }
    
    const patterns = [
      /\/d\/([a-zA-Z0-9-_]+)/,
      /spreadsheet\/d\/([a-zA-Z0-9-_]+)/,
      /\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1];
      }
    }
    
    return null;
  }

  async loadStyleSheets() {
    await this.loadLocalStyles();
  }

  async loadLocalStyles() {
    try {
      let styleFiles = [];
      try {
        const stylesResponse = await fetch('/styles');
        if (stylesResponse.ok) {
          const data = await stylesResponse.json();
          if (data?.ok && Array.isArray(data.files)) {
            styleFiles = data.files
              .filter(filename => this.isStyleJsonFile(filename))
              .map(filename => ({
                file: `style/${filename}`,
                name: filename.replace('.json', '')
              }));
          }
        }
      } catch (e) {
        console.log('Auto-discovery endpoint not available, falling back to manifest');
      }

      if (styleFiles.length === 0) {
        try {
          const manifestResponse = await fetch('style/manifest.json');
          if (manifestResponse.ok) {
            styleFiles = (await manifestResponse.json())
              .filter(styleInfo => this.isStyleJsonFile(styleInfo.file));
          }
        } catch (e) {
          console.log('Manifest file not found, using minimal default list');
        }
      }

      if (styleFiles.length === 0) {
        styleFiles = [
          { name: 'Minimal Card', file: 'style/minimal-card.json' },
          { name: 'Minimal Testimonial Card', file: 'style/testimonal.json' },
          { name: 'Testimonial with Rating', file: 'style/testimonial-rating.json' }
        ];
      }

      this.styleSets = [];
      for (const styleInfo of styleFiles) {
        try {
          const response = await fetch(styleInfo.file);
          if (!response.ok) {
            console.warn(`Failed to load ${styleInfo.file}: ${response.status}`);
            continue;
          }
          
          const styleSet = await response.json();
          
          // Ensure ID and name are present
          if (!styleSet.id) {
            styleSet.id = styleInfo.file.replace(/[\/\.]/g, '_');
          }
          if (!styleSet.name) {
            styleSet.name = styleInfo.name;
          }
          
          // Skip if we already have this style ID
          if (this.styleSets.some(s => s.id === styleSet.id)) {
            console.log(`Skipping duplicate style ID: ${styleSet.id}`);
            continue;
          }

          styleSet.category = this.normalizeStyleCategory(styleSet.category || styleInfo.category || 'general');
          styleSet.layout = {
            type: styleSet.layout?.type || 'card',
            width: styleSet.layout?.width || 'auto',
            fullWidth: styleSet.layout?.fullWidth || false,
            customWidth: styleSet.layout?.customWidth || 0,
            minHeight: styleSet.layout?.minHeight || 0,
            height: styleSet.layout?.height || 'auto'
          };
          styleSet.isNewFormat = true;
          if (styleSet.cardStyle) {
            styleSet.cardBg = styleSet.cardStyle.bg || '#ffffff';
            styleSet.cardBgDark = styleSet.cardStyle.bgDark || styleSet.cardStyle.bg || '#111827';
            styleSet.cardText = styleSet.cardStyle.text || '#1f2937';
            styleSet.cardTextDark = styleSet.cardStyle.textDark || styleSet.cardStyle.text || '#f9fafb';
            styleSet.cardBorder = styleSet.cardStyle.border || '#e5e7eb';
            styleSet.cardRadius = styleSet.cardStyle.radius || 12;
            styleSet.cardPadding = styleSet.cardStyle.padding || 16;
            styleSet.cardShadow = styleSet.cardStyle.shadow || 'md';
          } else {
            // Set default values if no cardStyle defined
            styleSet.cardBg = '#ffffff';
            styleSet.cardBgDark = '#111827';
            styleSet.cardText = '#1f2937';
            styleSet.cardTextDark = '#f9fafb';
            styleSet.cardBorder = '#e5e7eb';
            styleSet.cardRadius = 12;
            styleSet.cardPadding = 16;
            styleSet.cardShadow = 'md';
          }
          
          console.log(`Loaded style: ${styleSet.name} (ID: ${styleSet.id})`);
          this.styleSets.push(styleSet);
        } catch (error) {
          console.error(`Failed to parse ${styleInfo.file}:`, error);
        }
      }

      console.log(`Total styles loaded: ${this.styleSets.length}`);
      this.renderStyleCategoryOptions();
      this.renderStyleSelect();
    } catch (error) {
      console.error('Failed to load local styles:', error);
      this.showToast('Failed to load local styles: ' + error.message, 'error');
    }
  }

  isStyleJsonFile(filePath = '') {
    const filename = String(filePath).split('/').pop().toLowerCase();
    if (!filename.endsWith('.json')) {
      return false;
    }

    const excludedFiles = new Set([
      'manifest.json',
      'style_set_template.json'
    ]);

    return !excludedFiles.has(filename);
  }

  normalizeStyleCategory(category = 'general') {
    const normalized = String(category || 'general').trim().toLowerCase();
    const aliasMap = {
      hero: 'cta',
      ctahero: 'cta',
      'cta/hero': 'cta',
      testimonials: 'testimonial',
      reviews: 'testimonial',
      review: 'testimonial',
      products: 'product',
      pricingtable: 'pricing'
    };

    return aliasMap[normalized] || normalized;
  }

  getPreferredStyleCategories() {
    return [
      { value: 'nav', label: 'Nav' },
      { value: 'header', label: 'Header' },
      { value: 'cta', label: 'CTA / Hero' },
      { value: 'feature', label: 'Feature' },
      { value: 'product', label: 'Product' },
      { value: 'blog', label: 'Blog' },
      { value: 'testimonial', label: 'Testimonials' },
      { value: 'pricing', label: 'Pricing' },
      { value: 'sidebar', label: 'Sidebar' },
      { value: 'form', label: 'Form' },
      { value: 'table', label: 'Table' },
      { value: 'footer', label: 'Footer' },
      { value: 'button', label: 'Button' }
    ];
  }

  renderStyleCategoryOptions() {
    const categoryFilter = document.getElementById('styleCategoryFilter');
    if (!categoryFilter) return;

    const previousValue = categoryFilter.value || 'all';
    const categories = this.getPreferredStyleCategories();

    categoryFilter.innerHTML = '';

    const allOption = document.createElement('option');
    allOption.value = 'all';
    allOption.textContent = 'All Styles';
    categoryFilter.appendChild(allOption);

    categories.forEach(category => {
      const option = document.createElement('option');
      option.value = category.value;
      option.textContent = category.label;
      categoryFilter.appendChild(option);
    });

    categoryFilter.value = categories.some(item => item.value === previousValue) || previousValue === 'all'
      ? previousValue
      : 'all';
  }

  renderStyleSelect() {
    const styleSelect = document.getElementById('styleSelect');
    if (!styleSelect) return;

    const category = this.normalizeStyleCategory(document.getElementById('styleCategoryFilter')?.value || 'all');
    const filteredStyles = category === 'all'
      ? this.styleSets
      : this.styleSets.filter(styleSet => this.normalizeStyleCategory(styleSet.category || 'general') === category);

    const sortedStyles = [...filteredStyles].sort((left, right) => {
      const leftCategory = left.category || 'general';
      const rightCategory = right.category || 'general';
      if (leftCategory !== rightCategory) {
        return leftCategory.localeCompare(rightCategory);
      }
      return (left.name || '').localeCompare(right.name || '');
    });

    styleSelect.innerHTML = '<option value="">Choose a style...</option>';
    sortedStyles.forEach(styleSet => {
      const option = document.createElement('option');
      option.value = styleSet.id;
      option.textContent = `${styleSet.name} · ${styleSet.category || 'general'}`;
      if (this.currentStyle && this.currentStyle.id === styleSet.id) {
        option.selected = true;
      }
      styleSelect.appendChild(option);
    });
  }

  async loadLocalStyle() {
    const styleId = document.getElementById('styleSelect').value;
    if (!styleId) {
      this.showToast('Please select a style', 'error');
      return;
    }

    try {
      const styleSet = this.styleSets.find(s => s.id === styleId);
      if (!styleSet) {
        throw new Error('Style not found');
      }

      console.log('=== Loading Style ===');
      console.log('Style ID:', styleId);
      console.log('Style name:', styleSet.name);
      console.log('Current sheet data count:', this.sheetData.length);
      console.log('Sections count:', this.sections.length);

      this.currentStyle = styleSet;

      let gridSection = this.sections.find(s => s.gridEnabled);
      if (gridSection) {
        console.log('Found grid section:', gridSection.id);
        gridSection.styleApplied = true;
        gridSection.styleSetId = styleSet.id;
        if (styleSet.grid) {
          gridSection.gridColumns = styleSet.grid.columns;
          gridSection.gridColumnsDesktop = styleSet.grid.columns || gridSection.gridColumnsDesktop || 4;
          gridSection.gridColumnsTablet = styleSet.grid.columnsTablet || gridSection.gridColumnsTablet || 2;
          gridSection.gridColumnsPhone = styleSet.grid.columnsPhone || gridSection.gridColumnsPhone || 1;
          gridSection.gridGap = styleSet.grid.gap;
          gridSection.gridMinWidth = styleSet.grid.minWidth;
          gridSection.gridMaxWidth = styleSet.grid.maxWidth;
          if (styleSet.grid.cardLimit !== undefined) {
            gridSection.gridCardLimit = styleSet.grid.cardLimit;
          }
        }
        gridSection.cardWidthMode = styleSet.layout?.width || 'auto';
        gridSection.cardCustomWidth = styleSet.layout?.customWidth || 0;
        gridSection.sectionFullWidth = !!styleSet.layout?.fullWidth;
        gridSection.sectionMinHeight = styleSet.layout?.minHeight || 0;
        this.syncGridControls(gridSection);
      } else {
        console.log('No grid section found, creating one automatically...');
        gridSection = {
          id: Date.now(),
          name: 'Grid Section',
          content: '',
          className: 'grid-section',
          visible: true,
          gridEnabled: true,
          gridColumns: styleSet.grid?.columns || this.gridConfig.columns || 4,
          gridColumnsDesktop: styleSet.grid?.columns || this.gridConfig.columnsDesktop || 4,
          gridColumnsTablet: styleSet.grid?.columnsTablet || this.gridConfig.columnsTablet || 2,
          gridColumnsPhone: styleSet.grid?.columnsPhone || this.gridConfig.columnsPhone || 1,
          gridGap: styleSet.grid?.gap || this.gridConfig.gap || 24,
          gridMinWidth: styleSet.grid?.minWidth || this.gridConfig.minWidth || 280,
          gridMaxWidth: styleSet.grid?.maxWidth || this.gridConfig.maxWidth || 1440,
          gridCardLimit: styleSet.grid?.cardLimit ?? this.gridConfig.cardLimit ?? 0,
          cardWidthMode: styleSet.layout?.width || 'auto',
          cardCustomWidth: styleSet.layout?.customWidth || 0,
          sectionFullWidth: !!styleSet.layout?.fullWidth,
          sectionMinHeight: styleSet.layout?.minHeight || 0,
          styleApplied: true,
          styleSetId: styleSet.id
        };
        this.sections.push(gridSection);
        console.log('Grid section created, ID:', gridSection.id);
        this.syncGridControls(gridSection);
      }


  this.updateStylePanelFromCurrentStyle(styleSet);
      this.renderStylePreview(styleSet);
      this.renderPreview();

      if (gridSection) {
        console.log('Switching to sections tab to show preview');
        this.switchTab('sections');
      } else {
        this.switchTab('styles');
      }

      this.showToast('Style applied successfully: ' + styleSet.name, 'success');
    } catch (error) {
      console.error('Failed to load style:', error);
      this.showToast('Failed to load style: ' + error.message, 'error');
    }
  }

  parseStyleFromSheet(data) {
    const styleSet = {
      id: Date.now(),
      name: data[0]?.name || 'Style from Sheet',
      description: data[0]?.description || '',
      cardBg: data[0]?.cardBg || '#ffffff',
      cardText: data[0]?.cardText || '#1f2937',
      cardBorder: data[0]?.cardBorder || '#e5e7eb',
      cardAccent: data[0]?.cardAccent || '#7c2bee',
      cardRadius: parseInt(data[0]?.cardRadius) || 12,
      cardPadding: parseInt(data[0]?.cardPadding) || 16,
      cardShadow: data[0]?.cardShadow || 'md',
      template: data[0]?.template ? JSON.parse(data[0].template) : null,
      dataMapping: data[0]?.dataMapping ? JSON.parse(data[0].dataMapping) : null,
      textStyles: data[0]?.textStyles ? JSON.parse(data[0].textStyles) : {},
      grid: data[0]?.grid ? JSON.parse(data[0].grid) : null,
      hover: data[0]?.hover ? JSON.parse(data[0].hover) : {},
      animation: data[0]?.animation ? JSON.parse(data[0].animation) : { enabled: false },
      isNewFormat: !!(data[0]?.template)
    };

    return styleSet;
  }

  getPreviewData(styleSet) {
    const fields = styleSet.fields || {};
    const isTestimonial = styleSet.id.includes('testimonial');
    
    return {
      image: fields.image?.default || (isTestimonial 
        ? 'https://via.placeholder.com/60x60/cccccc/000000?text=Client'
        : 'https://via.placeholder.com/400x400/1f2937/ffffff?text=Product'),
      name: fields.name?.default || (isTestimonial ? 'Lydia Chen' : 'Product Name'),
      description: fields.description?.default || (isTestimonial 
        ? 'ARKAL transformed our space with clear vision and thoughtful design. Every detail felt intentional.'
        : 'Product description text'),
      price: fields.price?.default || '$99',
      category: fields.category?.default || 'Category',
      badge: fields.badge?.default || '',
      buttonText: fields.buttonText?.default || 'Buy Now',
      author: fields.author?.default || 'Lydia Chen',
      role: fields.role?.default || 'Director, Arcadia Builders',
      title: fields.title?.default || (isTestimonial ? 'Client Stories' : 'Title')
    };
  }

  renderStylePreview(styleSet) {
    const previewContainer = document.getElementById('stylePreview');
    if (!previewContainer) {
      console.warn('stylePreview container not found');
      return;
    }

    let previewHtml = '';

    if (styleSet.isNewFormat && styleSet.template) {
      const previewData = this.getPreviewData(styleSet);
      
      if (previewData && styleSet.template.html) {
        const template = styleSet.template.html;
        const css = styleSet.template.css || '';
        const cardStyle = styleSet.cardStyle || {};
        const bg = cardStyle.bg || '#ffffff';
        const text = cardStyle.text || '#1f2937';
        const border = cardStyle.border || '#e5e7eb';
        const radius = cardStyle.radius || 12;
        const padding = cardStyle.padding || 16;
        const shadow = cardStyle.shadow || '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
        const textStyles = styleSet.textStyles || {};
        
        let textStylesCSS = '';
        for (const [field, style] of Object.entries(textStyles)) {
          const cssVars = [
            `--${field}-font-size: ${style.fontSize}px`,
            `--${field}-font-weight: ${style.fontWeight}`,
            `--${field}-color: ${style.color}`,
            `--${field}-line-height: ${style.lineHeight}`,
            `--${field}-letter-spacing: ${style.letterSpacing}px`,
            `--${field}-text-align: ${style.textAlign}`,
            `--${field}-text-transform: ${style.textTransform}`
          ];
          textStylesCSS += cssVars.join('; ') + '; ';
        }

        let filledTemplate = template;
        for (const key in previewData) {
          let value = previewData[key];
          
          if (key === 'image' && value) {
            value = this.convertGoogleDriveUrl(value);
          }
          
          filledTemplate = filledTemplate.replace(new RegExp(`{{${key}}}`, 'g'), value || '');
        }

        previewHtml = `
          <div class="card-preview-wrapper" style="max-width: 300px;">
            <style>
              .card-preview-wrapper {
                --card-bg: ${bg};
                --card-text: ${text};
                --card-border: ${border};
                --card-radius: ${radius}px;
                --card-padding: ${padding}px;
                --card-shadow: ${shadow};
                ${textStylesCSS}
              }
              ${css}
            </style>
            ${filledTemplate}
          </div>
        `;
      }
    }

    previewContainer.innerHTML = previewHtml || '<p>No preview available</p>';
  }

  addTallySection() {
    const directUrl = document.getElementById('tallyDirectUrl').value.trim();
    const embedCode = document.getElementById('tallyEmbedCode').value.trim();
    const width = parseInt(document.getElementById('tallyWidth').value) || 1200;
    const paddingTop = parseInt(document.getElementById('tallyPaddingTop').value) || 60;
    const paddingBottom = parseInt(document.getElementById('tallyPaddingBottom').value) || 60;
    const paddingLeft = parseInt(document.getElementById('tallyPaddingLeft').value) || 20;
    const paddingRight = parseInt(document.getElementById('tallyPaddingRight').value) || 20;

    console.log('=== Adding NEW Tally Section ===');
    console.log('Direct URL input:', directUrl);
    console.log('Embed code input length:', embedCode.length);

    // User must provide one of the two methods
    if (!directUrl && !embedCode) {
      this.showToast('Please enter a Tally link OR embed code', 'error');
      return;
    }

    // Prioritize embed code if both are provided
    let embedUrl = null;
    let embedHtml = null;
    
    if (embedCode) {
      console.log('=== Using embed code (Method 2) ===');
      // Extract just the iframe tag, remove the script
      const iframeMatch = embedCode.match(/<iframe[^>]*data-tally-src[^>]*><\/iframe>/);
      if (iframeMatch) {
        embedHtml = iframeMatch[0];
        console.log('Extracted iframe from embed code:', embedHtml.substring(0, 100) + '...');
      } else {
        // Try alternate pattern: match iframe with optional closing tag  
        const altMatch = embedCode.match(/<iframe[^>]*>/);
        if (altMatch) {
          // Extract the iframe opening tag only
          embedHtml = altMatch[0];
          // If it doesn't have a closing tag, add one
          if (!embedHtml.endsWith('/>')) {
            embedHtml += '</iframe>';
          }
          console.log('Extracted iframe (alt method):', embedHtml.substring(0, 100) + '...');
        } else {
          // If no match, use the whole thing (might contain <script> tags too)
          embedHtml = embedCode;
          console.log('Using entire embed code as-is');
        }
      }
    } else if (directUrl) {
      console.log('=== Using direct URL (Method 1) ===');
      // Validate that it's a tally URL
      if (!directUrl.includes('tally.so')) {
        this.showToast('Invalid Tally URL. Must contain "tally.so"', 'error');
        return;
      }
      embedUrl = this.normalizeTallyUrl(directUrl);
    }

    console.log('Final embed URL:', embedUrl);
    console.log('embedHtml content:', embedHtml ? `YES (${embedHtml.length} chars)` : 'NO');

    // Always add a new section (don't update existing)
    const sectionData = {
      id: Date.now(),
      name: 'Tally Form',
      type: 'tally',
      url: embedUrl,
      embedHtml: embedHtml,
      visible: true,
      config: {
        width: Math.min(Math.max(width, 320), 1440),
        padding: {
          top: paddingTop,
          bottom: paddingBottom,
          left: paddingLeft,
          right: paddingRight
        }
      }
    };
    console.log('Adding new Tally section:', sectionData);
    this.sections.push(sectionData);
    this.showToast('Tally form section added', 'success');

    console.log('Sections count after adding Tally:', this.sections.length);
    console.log('All sections:', this.sections.map(s => ({ id: s.id, name: s.name, type: s.type, url: s.url, hasEmbedHtml: !!s.embedHtml })));

    this.saveData();
    this.switchTab('sections');
    this.renderSections();
    this.renderPreview();
  }

  applyTallySettings() {
    // Only apply settings to an already selected Tally section
    if (!this.selectedSection || this.selectedSection.type !== 'tally') {
      this.showToast('Please select a Tally section first', 'error');
      return;
    }

    const width = parseInt(document.getElementById('tallyWidth').value) || 1200;
    const paddingTop = parseInt(document.getElementById('tallyPaddingTop').value) || 60;
    const paddingBottom = parseInt(document.getElementById('tallyPaddingBottom').value) || 60;
    const paddingLeft = parseInt(document.getElementById('tallyPaddingLeft').value) || 20;
    const paddingRight = parseInt(document.getElementById('tallyPaddingRight').value) || 20;

    console.log('=== Applying Tally Settings ===');
    console.log('Selected section ID:', this.selectedSection.id);
    console.log('Updating config - width:', width, 'padding:', { top: paddingTop, bottom: paddingBottom, left: paddingLeft, right: paddingRight });

    // Update only the configuration, not the URL or embedHtml
    this.selectedSection.config = {
      width: Math.min(Math.max(width, 320), 1440),
      padding: {
        top: paddingTop,
        bottom: paddingBottom,
        left: paddingLeft,
        right: paddingRight
      }
    };

    console.log('Updated section config:', this.selectedSection.config);
    this.showToast('Tally settings applied', 'success');

    this.saveData();
    this.renderPreview();
  }

  normalizeTallyUrl(url) {
    if (!url) return url;
    
    console.log('normalizeTallyUrl input:', url);
    
    // If URL already has all parameters, return as-is
    if (url.includes('alignLeft=1') && url.includes('hideTitle=1') && url.includes('transparentBackground=1')) {
      console.log('URL already has all parameters, returning as-is');
      return url;
    }

    // Extract form ID from different URL formats
    let formId = null;
    
    // Format: https://tally.so/embed/7RKXAa?...
    const embedMatch = url.match(/tally\.so\/embed\/([a-zA-Z0-9]+)/);
    if (embedMatch && embedMatch[1]) {
      formId = embedMatch[1];
      console.log('Found form ID from /embed/ URL:', formId);
    }
    
    // Format: https://tally.so/r/7RKXAa
    if (!formId) {
      const rMatch = url.match(/tally\.so\/r\/([a-zA-Z0-9]+)/);
      if (rMatch && rMatch[1]) {
        formId = rMatch[1];
        console.log('Found form ID from /r/ URL:', formId);
      }
    }
    
    // Format: https://tally.so/7RKXAa
    if (!formId) {
      const directMatch = url.match(/tally\.so\/([a-zA-Z0-9]+)(?:[/?]|$)/);
      if (directMatch && directMatch[1]) {
        formId = directMatch[1];
        console.log('Found form ID from direct URL:', formId);
      }
    }
    
    if (formId) {
      const result = `https://tally.so/embed/${formId}?alignLeft=1&hideTitle=1&transparentBackground=1&dynamicHeight=1`;
      console.log('Normalized URL:', result);
      return result;
    }
    
    console.log('Could not extract form ID, returning original URL');
    return url;
  }

  async loadStyleFiles() {
    try {
      this.styleSets = [];

      if (typeof STYLE_SETS !== 'undefined' && STYLE_SETS.length > 0) {
        console.log('Loading style sets from STYLE_SETS constant:', STYLE_SETS.length);

        for (const styleData of STYLE_SETS) {
          const isNewFormat = styleData.template && (styleData.template.html || styleData.template.css);

          const styleSet = {
            id: styleData.id || Date.now() + Math.random(),
            name: styleData.name || 'Untitled Style',
            description: styleData.description || '',
            cardBg: styleData.cardBg || styleData.cardStyle?.bg || '#ffffff',
            cardText: styleData.cardText || styleData.cardStyle?.text || '#1f2937',
            cardBorder: styleData.cardBorder || styleData.cardStyle?.border || '#e5e7eb',
            cardAccent: styleData.cardAccent || styleData.fields?.price?.color || '#7c2bee',
            cardRadius: styleData.cardRadius || styleData.cardStyle?.radius || 12,
            cardPadding: styleData.cardPadding || styleData.cardStyle?.padding || 16,
            cardShadow: styleData.cardShadow || styleData.cardStyle?.shadow || 'md',
            fields: styleData.fields || {},
            hover: styleData.hover || {},
            template: styleData.template || null,
            grid: styleData.grid || null,
            dataMapping: styleData.dataMapping || null,
            textStyles: styleData.textStyles || {},
            animation: styleData.animation || { enabled: false },
            isNewFormat: isNewFormat
          };

          this.styleSets.push(styleSet);
          console.log(`Loaded style set: ${styleSet.name}`);
        }
      }

      await this.loadStyleJSONFiles();

      if (this.styleSets.length > 0 && !this.currentStyle) {
        this.currentStyle = this.styleSets[0];
      }

      console.log(`Total style sets loaded: ${this.styleSets.length}`);
      console.log('Style sets:', this.styleSets);
      this.renderStyleSets();
    } catch (error) {
      console.log('Failed to load style files:', error);
      console.error('Error details:', error);
    }
  }

  async loadStyleJSONFiles() {
    let styleFiles = [
      'style/card.json',
      'style/card_style_testimonal.json',
      'style/minimal-card.json',
      'style/testimonal.json'
    ];

    // Try server-provided list of style files at /styles (enabled by start-server.py)
    try {
      const resp = await fetch('/styles');
      if (resp.ok) {
        const data = await resp.json();
        if (data && Array.isArray(data.files) && data.files.length > 0) {
          styleFiles = data.files.map(f => `style/${f}`);
        }
      }
    } catch (e) {
      console.log('Failed to fetch /styles, falling back to built-in list:', e);
    }

    for (const filePath of styleFiles) {
      try {
        const response = await fetch(filePath);
        if (response.ok) {
          const styleData = await response.json();
          const isNewFormat = styleData.template && (styleData.template.html || styleData.template.css);
          
          let dataMapping = styleData.dataMapping || null;
          let fields = styleData.fields || {};
          let template = styleData.template || null;

          if (styleData.data_binding && !dataMapping) {
            dataMapping = {};
            fields = {};
            
            for (const [key, value] of Object.entries(styleData.data_binding)) {
              const placeholder = value.replace('{{', '').replace('}}', '');
              dataMapping[placeholder] = [placeholder, key];
              fields[placeholder] = {
                required: true,
                default: ''
              };
            }
            
            if (styleData.layout) {
              const cardRadius = styleData.layout.padding || 24;
              template = {
                html: `<div class="card-inner" style="display: flex; gap: ${styleData.layout.gap || 24}px; padding: ${styleData.layout.padding || 24}px; background: ${styleData.style?.background || '#ffffff'}; border-radius: ${styleData.style?.borderRadius || cardRadius}px; border: ${styleData.style?.border || '1px solid rgba(0,0,0,0.08)'};">` +
                  `<div style="flex: ${styleData.columns?.[0]?.widthPercent || 38}%;">` +
                    `<div style="font-size: 14px; font-weight: 500; color: rgba(0,0,0,0.72); margin-bottom: 18px;">Client Stories</div>` +
                    `<div style="font-family: ui-serif, Georgia, serif; font-size: 44px; line-height: 1.08; color: #111111; margin-bottom: 18px;">{{review}}</div>` +
                    `<div style="font-size: 16px; font-weight: 600; color: #111111;">{{name}}</div>` +
                    `<div style="font-size: 14px; font-weight: 500; color: rgba(0,0,0,0.62);">{{position}}</div>` +
                  `</div>` +
                  `<div style="flex: ${styleData.columns?.[1]?.widthPercent || 62}%;">` +
                    `<img src="{{image_url}}" alt="{{name}}" style="width: 100%; height: 100%; min-height: ${styleData.layout?.minHeight || 420}px; object-fit: cover; border-radius: ${styleData.style?.borderRadius || 18}px;">` +
                  `</div>` +
                `</div>`,
                css: ''
              };
              
              if (!fields['review']) fields['review'] = { required: true, default: 'Amazing experience!' };
              if (!fields['name']) fields['name'] = { required: true, default: 'Client Name' };
              if (!fields['position']) fields['position'] = { required: true, default: 'Position' };
              if (!fields['image_url']) fields['image_url'] = { required: true, default: 'https://via.placeholder.com/600x400' };
            }
          }

          const styleSet = {
            id: styleData.id || Date.now() + Math.random(),
            name: styleData.name || styleData.type || 'Untitled Style',
            description: styleData.description || '',
            cardBg: styleData.cardBg || styleData.cardStyle?.bg || styleData.style?.background || '#ffffff',
            cardText: styleData.cardText || styleData.cardStyle?.text || styleData.style?.color || '#1f2937',
            cardBorder: styleData.cardBorder || styleData.cardStyle?.border || styleData.style?.border || '#e5e7eb',
            cardAccent: styleData.cardAccent || styleData.fields?.price?.color || '#7c2bee',
            cardRadius: styleData.cardRadius || styleData.cardStyle?.radius || styleData.style?.borderRadius || 12,
            cardPadding: styleData.cardPadding || styleData.cardStyle?.padding || styleData.layout?.padding || 16,
            cardShadow: styleData.cardShadow || styleData.cardStyle?.shadow || styleData.style?.boxShadow || 'md',
            fields: fields,
            hover: styleData.hover || {},
            template: template,
            grid: styleData.grid || null,
            dataMapping: dataMapping,
            textStyles: styleData.textStyles || {},
            animation: styleData.animation || { enabled: false },
            isNewFormat: isNewFormat || template !== null
          };

          const existingIndex = this.styleSets.findIndex(s => s.id === styleSet.id);
          if (existingIndex === -1) {
            this.styleSets.push(styleSet);
            console.log(`Loaded JSON style: ${styleSet.name} from ${filePath}`);
          } else {
            this.styleSets[existingIndex] = styleSet;
            console.log(`Updated JSON style: ${styleSet.name} from ${filePath}`);
          }
        }
      } catch (error) {
        console.log(`Failed to load style file ${filePath}:`, error);
      }
    }
  }

  showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
        ${type === 'success' ? '<path d="M10 0a10 10 0 100 20 10 10 0 000-20zm-2 15l-5-5 1.41-1.41L8 12.17l7.59-7.59L17 6l-9 9z"/>' : ''}
        ${type === 'error' ? '<path d="M10 0a10 10 0 100 20 10 10 0 000-20zm1 15H9v-2h2v2zm0-4H9V5h2v6z"/>' : ''}
      </svg>
      <span>${message}</span>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'slideIn 0.3s ease reverse';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }
}

// ============================================
// 诊断工具 - 在控制台中使用
// ============================================

window.tallyDiagnostics = {
  /**
   * 显示所有保存的数据
   */
  showAllData() {
    const saved = localStorage.getItem('auraCanvasData');
    if (!saved) {
      console.log('No saved data found in localStorage');
      return null;
    }
    const data = JSON.parse(saved);
    console.log('=== All Saved Data ===');
    console.log(data);
    return data;
  },

  /**
   * 显示所有 Tally section
   */
  showTallyData() {
    const data = this.showAllData();
    if (!data || !data.sections) return null;
    const tallySections = data.sections.filter(s => s.type === 'tally');
    console.log('=== Tally Sections ===');
    console.log(`Total Tally sections: ${tallySections.length}`);
    tallySections.forEach((s, i) => {
      console.log(`[${i}]`, {
        id: s.id,
        name: s.name,
        hasUrl: !!s.url,
        url: s.url ? s.url.substring(0, 50) + '...' : null,
        hasEmbedHtml: !!s.embedHtml,
        embedHtmlLength: s.embedHtml ? s.embedHtml.length : 0,
        config: s.config
      });
    });
    return tallySections;
  },

  /**
   * 检查是否有损坏的 URL
   */
  checkCorruptedUrls() {
    const data = this.showAllData();
    if (!data || !data.sections) return [];
    
    const corrupted = [];
    data.sections.filter(s => s.type === 'tally' && s.url).forEach(s => {
      if (s.url.includes('igenLeft') || s.url.includes('icHeight') || s.url.includes('2a1')) {
        corrupted.push({
          id: s.id,
          url: s.url
        });
      }
    });
    
    if (corrupted.length > 0) {
      console.warn('❌ Found corrupted URLs:', corrupted);
    } else {
      console.log('✅ No corrupted URLs found');
    }
    return corrupted;
  },

  /**
   * 清空所有 Tally section
   */
  clearAllTally() {
    const data = this.showAllData();
    if (!data) {
      console.log('No data to clear');
      return;
    }
    data.sections = data.sections.filter(s => s.type !== 'tally');
    localStorage.setItem('auraCanvasData', JSON.stringify(data));
    console.log('✅ All Tally sections cleared');
    location.reload();
  },

  /**
   * 清空所有存储
   */
  clearAll() {
    if (confirm('Clear ALL data? This cannot be undone.')) {
      localStorage.clear();
      sessionStorage.clear();
      indexedDB.deleteDatabase('SheetCache');
      console.log('✅ All storage cleared');
      location.reload();
    }
  },

  /**
   * 测试 URL 规范化
   */
  testUrlNormalization(url) {
    console.log('=== Testing URL Normalization ===');
    console.log('Input:', url);
    const normalized = editor.normalizeTallyUrl(url);
    console.log('Output:', normalized);
    return normalized;
  },

  /**
   * 获取统计信息
   */
  getStats() {
    const data = this.showAllData();
    if (!data) {
      console.log('No data found');
      return null;
    }
    
    const stats = {
      totalSections: data.sections.length,
      tallyCount: data.sections.filter(s => s.type === 'tally').length,
      gridCount: data.sections.filter(s => s.gridEnabled).length,
      htmlCount: data.sections.filter(s => s.type !== 'tally' && !s.gridEnabled).length,
      totalStyles: data.styleSets.length,
      currentStyle: data.currentStyle?.name || 'None',
      gridConfig: data.gridConfig,
      hasSheetData: editor.sheetData.length > 0,
      sheetDataCount: editor.sheetData.length
    };
    
    console.log('=== Statistics ===');
    console.table(stats);
    return stats;
  },

  /**
   * 帮助信息
   */
  help() {
    console.log(`
    Tally 诊断工具 - 可用命令：
    
    📊 数据查询：
    - tallyDiagnostics.showAllData()      查看所有保存数据
    - tallyDiagnostics.showTallyData()    查看所有 Tally section
    - tallyDiagnostics.checkCorruptedUrls() 检查损坏的 URL
    - tallyDiagnostics.getStats()         获取统计信息
    
    🔧 维护操作：
    - tallyDiagnostics.clearAllTally()    清空所有 Tally section
    - tallyDiagnostics.clearAll()         清空所有数据（需确认）
    
    🧪 测试：
    - tallyDiagnostics.testUrlNormalization(url) 测试 URL 处理
    
    💡 示例：
    tallyDiagnostics.testUrlNormalization('https://tally.so/embed/7RKXAa')
    `);
  }
};

// 自动打印帮助信息
console.log('💡 Tally 诊断工具已加载。输入 tallyDiagnostics.help() 查看可用命令。');

// Initialize editor
const editor = new AuraCanvasEditor();
editor.init();